//_________________________________________________________________________________________
//            Class to perform unbinned log-likelihood fit
//          Origin: Run-2 AliPhysics codes based on AliDielectronBtoJPSItoEle
// Contact: shreyasi.acharya@cern.ch; fiorella.fionda@cern.ch; Giuseppe.Bruno@cern.ch
//_________________________________________________________________________________________


#include "TROOT.h"
#include "TFile.h"
#include "TNtuple.h"
#include "TCanvas.h"
#include "TF1.h"
#include "TFitResult.h"
#include "TH1F.h"
#include "TLatex.h"
#include "TDatabasePDG.h"
#include "TString.h"
#include "TMath.h"
#include "TStopwatch.h"
#include "TMinuit.h"
#include "TKey.h"
#include "TFitter.h"
#include "TStyle.h"
#include "TFFTReal.h"
#include "TMath.h"
#include "TComplex.h"
#include "Math/MinimizerOptions.h"
#include "TVectorT.h"
#include "Math/PdfFuncMathCore.h"
#include "AddFunctionDefinition.C"

void MakeReducedNtuple_New(std::vector<TString> &fileNames, TNtuple *ntNew, Double_t ptmin = 0., Double_t ptmax = 200., Double_t mMin1 = 2, Double_t mMax1 = 6., Int_t fAmbiIn = 9, Int_t fAmbiOut = 9, TH1F *h = 0x0, Bool_t isMC = false, Int_t iPlus = 1);
Double_t EvaluateCrystallBall(Double_t *m, Double_t *fPar);
Double_t EvaluateExponential(Double_t *m, Double_t *fPar);
Double_t EvaluateGaussian(Double_t *m, Double_t *fPar);
Double_t EvaluatePolynomial(Double_t *m, Double_t *fPar);
Double_t EvaluateCBplusGaus(Double_t *m, Double_t *fPar);
Double_t EvaluateCBplusExp(Double_t *m, Double_t *fPar);
Double_t EvaluateCBplusPolynomial(Double_t *m, Double_t *fPar);

void Fit_prompt_mass();
void Fit_data_mass();

Double_t massRangeMin = 2.10;
Double_t massRangeMax = 3.50;



int rebin = 2;

Double_t *pseudoproperTime = 0x0;
Double_t *mass = 0x0;
Double_t *pt = 0x0;
Int_t *type = 0;
Int_t nCand;

void Fit_JpsiMass(int kk = 10,  Bool_t isExpo = kTRUE)
{
    Double_t ptBins[] = {0., 0.5, 1., 1.5, 2., 2.5, 3., 3.5, 4., 4.5, 5, 6, 7., 8, 10, 12, 15, 20};
    Double_t ptMin = ptBins[kk];
    Double_t ptMax = ptBins[kk + 1];


    ROOT::Math::MinimizerOptions::SetDefaultMinimizer("Minuit");     // ("Minuit2,Migrad");
    ROOT::Math::MinimizerOptions::SetDefaultMaxIterations(10000000); // Increase max iterations
    ROOT::Math::MinimizerOptions::SetDefaultMaxFunctionCalls(10000000);

    //========================================================
    //===================== INPUT DATA =======================
    //========================================================

    std::vector<TString> fileNames;
    TString sFolder;
    TString inputData;
    TString sFolSave;
    TLegend *bMass; 
   

    if (ptMin <= 4.5) isExpo = kFALSE;

    sFolSave = "v7_4sigma_data_2024";
    inputData = Form("InputFiles/");
   
    //-------------DATA IN MASS----------
    TString sFile1 = Form("%s/dileptonAOD_Data_24pass1_4sigma.root", inputData.Data());
    fileNames.push_back(sFile1);

    //========================================================
    //===================== READ DATA ========================
    //========================================================

    float rangeMassHistoLow = 1.5;
    float rangeMassHistoHigh = 4.5;
    double nbins = 400;
    double binWidth = (rangeMassHistoHigh - rangeMassHistoLow) / nbins;

    //-------------MASS DATA----------

    TNtuple *ntJPsi_DataSig = new TNtuple("ntJPsi_DataSig", "ntJPsi_DataSig", "Xdecaytime:Mass:Pt:ambiInBunch:ambiOutOfBunch");
    TH1F *hpromptLxy_DataBkg = new TH1F("promptDataBkg_time", Form(""), 300, -1000, 2000);
    hpromptLxy_DataBkg->Sumw2();
    MakeReducedNtuple_New(fileNames, ntJPsi_DataSig, ptMin, ptMax, massRangeMin, massRangeMax, 9, 9, hpromptLxy_DataBkg, false, 1); //

    Double_t *pseudoproperTime = 0x0;
    Double_t *pseudoproperTime_Cut = 0x0;
    Double_t *mass = 0x0;
    Double_t *pt = 0x0;
    Bool_t *CorrAssocRecoMCnp = 0x0;
    Bool_t *ambIn = 0x0;
    Bool_t *ambOut = 0x0;
    Bool_t *corrA = 0x0;

    ReadCandidates(ntJPsi_DataSig, pseudoproperTime, mass, pt, ambIn, ambOut, corrA, nCand, false); // read N-Tuples from Data-Bkg

    TH1F *hData_InvMass = new TH1F("Data inv mass", "", nbins, rangeMassHistoLow, rangeMassHistoHigh);
    hData_InvMass->Sumw2();
    for (Int_t i = 0; i < nCand; i++)
        hData_InvMass->Fill(mass[i]);

    TH1F *hMass_Data = (TH1F *)hData_InvMass->Clone("hMass_Data");

    //========================================================
    //========================= DRAW =========================
    //========================================================

    TCanvas *c2 = new TCanvas("c2", "J/psi Mass Fit", 800, 600);
    c2->SetRightMargin(0.00877193);
    c2->SetTopMargin(0.01391304);
    c2->cd();
    hMass_Data->GetXaxis()->SetRangeUser(1.85, 3.65);

    hMass_Data->Rebin(rebin);
    hMass_Data->Scale(1. / rebin);
    hMass_Data->GetXaxis()->SetRangeUser(2, 3.55);
    hMass_Data->GetXaxis()->SetTitle("Inv. mass (data)");
    hMass_Data->Draw("Same");

    //-------------FIT MASS HIST----------

    TF1 *fTotal;
    TF1 *fBkg;
    TF1 *fCrystalBall_Data;
    int nParamaters;
    nParamaters = 11;
    TVectorD *params = new TVectorD(nParamaters + 1);

    if(!isExpo)
    {   
        bMass = new TLegend(0.1240602,0.6,0.2857143,0.9756522);
        fTotal = new TF1("fTotal", EvaluateCBplusPolynomial, massRangeMin, massRangeMax, nParamaters);
        if(ptMin >= 10){
            fTotal->SetParameters(1203.9, 3.04909, 0.0705694, 0.422586, 108221, 132568, -234960, 165315, -57430.4, 9845.6, -666); // 363.011, 3.03933, 0.0875891, 0.608881, 2566.7, 133270, -235612, 165256, -57380.1, 9861.86, -671.441
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            fTotal->SetParLimits(4, 4.05, 150000.5);
            fTotal->FixParameter(10, 0);
        }
        if(ptMin == 8){
            fTotal->SetParameters(1203.9, 3.04909, 0.0705694, 0.422586, 108221, 132568, -234960, 165315, -57430.4, 9845.6, -666); // 363.011, 3.03933, 0.0875891, 0.608881, 2566.7, 133270, -235612, 165256, -57380.1, 9861.86, -671.441
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            fTotal->SetParLimits(4, 4.05, 150000.5);
        }
        if(ptMin == 7){
            fTotal->SetParameters(1203.9, 3.04909, 0.0705694, 0.422586, 108221, 132568, -234960, 165315, -57430.4, 9845.6, -666);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            fTotal->SetParLimits(4, 4.05, 150000.5);
        }
        if(ptMin == 6){
            fTotal->SetParameters(3408.83, 3.05685, 0.056584, 0.460121, 1.78921, 218531, -359185, 235985, -75311.5, 11525, -668.359);
        }
        if(ptMin == 5){
            fTotal->SetParameters(2347.32, 3.0552, 0.0577661, 0.412105, 8.02215, 195560, -319137, 205066, -63832, 9536.87, -540.94);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            // fTotal->SetParLimits(4, 24.05, 150.5);
        }
        if(ptMin == 4.5){
            fTotal->SetParameters(2331.68, 3.05595, 0.0571547, 0.393812, 74.05, 194902, -318763, 205111, -63858.2, 9527.17, -538.323);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            // fTotal->SetParLimits(4, 24.05, 150.5);
        }
        if(ptMin == 4.0){
            bMass = new TLegend(0.1365915,0.1634783,0.2982456,0.5391304);
            fTotal->SetParameters(2331.68, 3.05595, 0.0571547, 0.393812, 174.05, 194902, -318763, 205111, -63858.2, 9527.17, -538.323);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            // fTotal->SetParLimits(4, 20.05, 150.5);
        }
        if(ptMin == 3.5 || ptMin == 3.0){
            bMass = new TLegend(0.1365915,0.1634783,0.2982456,0.5391304);
            fTotal->SetParameters(2331.68, 3.05595, 0.0571547, 0.393812, 174.05, 194902, -318763, 205111, -63858.2, 9527.17, -538.323);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            fTotal->SetParLimits(4, 20, 500.5);
        }
        if(ptMin == 2.5){
            bMass = new TLegend(0.1365915,0.1634783,0.2982456,0.5391304);
            fTotal->SetParameters(4220.91, 3.06399, 0.0470437, 0.382302, 20, 372171, -508087, 260198, -55027.8, 2793.04, 308);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            fTotal->SetParLimits(4, 20, 500.5);
        }
        if(ptMin == 2.0){
            bMass = new TLegend(0.1365915,0.1634783,0.2982456,0.5391304);
            fTotal->SetParameters(4220.91, 3.06399, 0.0470437, 0.382302, 20, 372171, -508087, 260198, -55027.8, 2793.04, 308);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            // fTotal->SetParLimits(4, 20, 500.5);
        }
        if(ptMin == 1.5){
            bMass = new TLegend(0.1365915,0.1634783,0.2982456,0.5391304);
            fTotal->SetParameters(5602.85, 3.06651, 0.0440606, 0.428657, 1.56875, 2.39367e+06, -4.46521e+06, 3.29004e+06, -1.19343e+06, 213429, -15081.8);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            fTotal->SetParLimits(4, 10, 1e7);
            // 5400.08, 3.06941, 0.0416573, 0.326368, 10, 2.38635e+06, -4.46098e+06, 3.2906e+06, -1.19374e+06, 213308, -15049.7
        }
        if(ptMin == 1.){
            bMass = new TLegend(0.1253133,0.6069565,0.2869674,0.9826087);
            fTotal->SetParameters(6439.49, 3.07279, 0.0389805, 0.264097, 1e6, 2.38416e+06, -4.46709e+06, 3.29108e+06, -1.19279e+06, 213531, -15154.5);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            // fTotal->SetParLimits(4, 10, 1e7);
            // 6268.15, 3.07218, 0.0379374, 0.311503, 3188.16, 2.47669e+06, -4.49678e+06, 3.20741e+06, -1.12382e+06, 194208, -13289.7, 

        }
        if(ptMin == 0.5 || ptMin == 0.){
            bMass = new TLegend(0.1253133,0.6069565,0.2869674,0.9826087);
            fTotal->SetParameters(2604.82, 3.07052, 0.029997, 0.608239, 1.70677, 551767, -788237, 372028, -50753.7, -6870.18, 1638.68);
            fTotal->SetParLimits(1, 3.02, 3.1);
            fTotal->SetParLimits(2, 0.015, 0.09);
            fTotal->SetParLimits(3, 0.0, 2.8);
            // fTotal->SetParLimits(4, 10, 1e7);
            // 6268.15, 3.07218, 0.0379374, 0.311503, 3188.16, 2.47669e+06, -4.49678e+06, 3.20741e+06, -1.12382e+06, 194208, -13289.7, 
        }
        //========================================================
        //========================= FIT =========================
        //========================================================

        hMass_Data->Fit(fTotal, "R0");

        (*params)[0] = fTotal->GetParameter(0);
        (*params)[1] = fTotal->GetParameter(1);
        (*params)[2] = fTotal->GetParameter(2);
        (*params)[3] = fTotal->GetParameter(3);
        (*params)[4] = fTotal->GetParameter(4);
        (*params)[5] = fTotal->GetParameter(5);
        (*params)[6] = fTotal->GetParameter(6);
        (*params)[7] = fTotal->GetParameter(7);
        (*params)[8] = fTotal->GetParameter(8);
        (*params)[9] = fTotal->GetParameter(9);
        (*params)[10] = fTotal->GetParameter(10);

        hMass_Data->Draw();
        fTotal->SetLineColor(kBlack);

        fBkg = new TF1("fBkg", EvaluatePolynomial, massRangeMin, massRangeMax, 6);
        fBkg->SetParameters(fTotal->GetParameter(5), fTotal->GetParameter(6), fTotal->GetParameter(7), fTotal->GetParameter(8), fTotal->GetParameter(9), fTotal->GetParameter(10));
        fBkg->SetLineColor(kRed);

        fCrystalBall_Data = new TF1("fCrystalBall_Data", "crystalball", massRangeMin, massRangeMax);
        fCrystalBall_Data->SetParameters(fTotal->GetParameter(0), fTotal->GetParameter(1), fTotal->GetParameter(2), fTotal->GetParameter(3), fTotal->GetParameter(4));
        fCrystalBall_Data->SetLineColor(kGreen);

        fTotal->Draw("SAME");
        fCrystalBall_Data->Draw("SAME");
        fBkg->Draw("SAME");
    }
    if(isExpo && ptMin >= 4.5){ 
        bMass = new TLegend(0.1240602,0.6,0.2857143,0.9756522);
        fTotal = new TF1("fTotal", EvaluateCBplusExp, massRangeMin, massRangeMax, nParamaters);
        fTotal->SetParameters(1000, 3.066, 0.057, 0.5, 1.53584, 506.32, 1, -0.35);
        fTotal->SetParLimits(1, 3.02, 3.1);
        fTotal->SetParLimits(2, 0.045, 0.5);
        fTotal->SetParLimits(3, 0.05, 0.99);
        fTotal->SetParLimits(4, 0.05, 5.5);
        fTotal->SetParLimits(5, 0, 100000.33);
        // fTotal->SetParLimits(6, 0.001, 10);
       
        //========================================================
        //========================= FIT =========================
        //========================================================

        hMass_Data->Fit(fTotal, "R0");

        (*params)[0] = fTotal->GetParameter(0);
        (*params)[1] = fTotal->GetParameter(1);
        (*params)[2] = fTotal->GetParameter(2);
        (*params)[3] = fTotal->GetParameter(3);
        (*params)[4] = fTotal->GetParameter(4);
        (*params)[5] = fTotal->GetParameter(5);
        (*params)[6] = fTotal->GetParameter(6);
        (*params)[7] = fTotal->GetParameter(7);
        (*params)[8] = 0;
        (*params)[9] = 0;
        (*params)[10] = 0;

        hMass_Data->Draw();
        fTotal->SetLineColor(kBlack);

        fBkg = new TF1("fBkg", EvaluateExponential, massRangeMin, massRangeMax, 3);
        fBkg->SetParameters(fTotal->GetParameter(5), fTotal->GetParameter(6), fTotal->GetParameter(7));
        fBkg->SetLineColor(kRed);

        fCrystalBall_Data = new TF1("fCrystalBall_Data", "crystalball", massRangeMin, massRangeMax);
        fCrystalBall_Data->SetParameters(fTotal->GetParameter(0), fTotal->GetParameter(1), fTotal->GetParameter(2), fTotal->GetParameter(3), fTotal->GetParameter(4));
        fCrystalBall_Data->SetLineColor(kGreen);

        fTotal->Draw("SAME");
        fCrystalBall_Data->Draw("SAME");
        fBkg->Draw("SAME");
         
    }
    cout << endl;
    TVectorD *parChi2ndf = new TVectorD(3);
    (*parChi2ndf)[0] = fTotal->GetChisquare();
    (*parChi2ndf)[1] = fTotal->GetNDF();
    (*parChi2ndf)[2] = fTotal->GetChisquare() / fTotal->GetNDF();

    cout << "Chi2 = " << fTotal->GetChisquare() << " ndf = " << fTotal->GetNDF() << " chi2/ndf = " << fTotal->GetChisquare() / fTotal->GetNDF() << endl;

    for (int ii = 0; ii < nParamaters; ii++)
    {
        cout << fTotal->GetParameter(ii) << ", ";
    }
    cout << "\n\n\n";
    float mass1 = 3.3;
    float mass2 = 3.4;
    mass1 = 2.4;
    mass2 = 3.2;

    float intgBkg = fBkg->Integral(mass1, mass2);
    float intgCBData = fCrystalBall_Data->Integral(mass1, mass2);
    float SignalFrac_2o4_3o2 = intgCBData / (intgCBData + intgBkg);
    cout << mass1 << "-" << mass2 << " => " << intgCBData << "  " << intgBkg << " signal fraction = " << SignalFrac_2o4_3o2 << endl;

    cout << " ===== " << endl;
    mass1 = 2.1;
    mass2 = 2.2;
    intgBkg = fBkg->Integral(mass1, mass2);
    intgCBData = fCrystalBall_Data->Integral(mass1, mass2);
    float SignalFrac_2o1_2o2 = intgCBData / (intgCBData + intgBkg);
    cout << mass1 << "-" << mass2 << " => " << intgCBData << "  " << intgBkg << " signal fraction = " << SignalFrac_2o1_2o2 << endl;

    mass1 = 2.2;
    mass2 = 2.4;
    intgBkg = fBkg->Integral(mass1, mass2);
    intgCBData = fCrystalBall_Data->Integral(mass1, mass2);
    float SignalFrac_2o2_2o4 = intgCBData / (intgCBData + intgBkg);
    cout << mass1 << "-" << mass2 << " => " << intgCBData << "  " << intgBkg << " signal fraction = " << SignalFrac_2o2_2o4 << endl;

    mass1 = 2.7;
    mass2 = 3.2;
    intgBkg = fBkg->Integral(mass1, mass2);
    intgCBData = fCrystalBall_Data->Integral(mass1, mass2);
    float SignalFrac_2o7_3o2 = intgCBData / (intgCBData + intgBkg);
    cout << mass1 << "-" << mass2 << " => " << intgCBData << "  " << intgBkg << " signal fraction = " << SignalFrac_2o7_3o2 << endl;

    mass1 = 3.2;
    mass2 = 3.3;
    intgBkg = fBkg->Integral(mass1, mass2);
    intgCBData = fCrystalBall_Data->Integral(mass1, mass2);
    float SignalFrac_3o2_3o3 = intgCBData / (intgCBData + intgBkg);
    cout << mass1 << "-" << mass2 << " => " << intgCBData << "  " << intgBkg << " signal fraction = " << SignalFrac_3o2_3o3 << endl;

    mass1 = 3.3;
    mass2 = 3.4;
    intgBkg = fBkg->Integral(mass1, mass2);
    intgCBData = fCrystalBall_Data->Integral(mass1, mass2);
    float SignalFrac_3o3_3o4 = intgCBData / (intgCBData + intgBkg);
    cout << mass1 << "-" << mass2 << " => " << intgCBData << "  " << intgBkg << " signal fraction = " << SignalFrac_3o3_3o4 << endl;

    TVectorD *paramSignalFrac = new TVectorD(2);
    (*paramSignalFrac)[0] = SignalFrac_2o7_3o2;
    (*paramSignalFrac)[1] = SignalFrac_2o4_3o2;

    //========================================================
    //==================== LEGEND ==============================
    //========================================================

    // TLegend *bMass = new TLegend(0.1240602,0.6,0.2857143,0.9756522);
    bMass->SetTextSize(0.035);
    bMass->SetBorderSize(0);
    bMass->SetFillStyle(0);
    bMass->AddEntry("NULL", Form("%0.02f < #it{p}^{ee}_{T} < %0.02f GeV/#it{c}", ptMin, ptMax), "hc");
    bMass->AddEntry("NULL", Form("#chi^{2}/ndf = %0.02f", (*parChi2ndf)[2]), "hc");
    bMass->AddEntry("NULL", Form("#bf{2.40 - 3.20 GeV/#it{c}^{2}, #it{f}_{sig} = %0.03f}", SignalFrac_2o4_3o2), "");
    bMass->AddEntry("NULL", Form("2.10 - 2.20 GeV/#it{c}^{2}, #it{f}_{sig} = %0.03f", SignalFrac_2o1_2o2), "");
    bMass->AddEntry("NULL", Form("2.20 - 2.40 GeV/#it{c}^{2}, #it{f}_{sig} = %0.03f", SignalFrac_2o2_2o4), "");
    bMass->AddEntry("NULL", Form("2.70 - 3.20 GeV/#it{c}^{2}, #it{f}_{sig} = %0.03f", SignalFrac_2o7_3o2), "");
    bMass->AddEntry("NULL", Form("3.20 - 3.30 GeV/#it{c}^{2}, #it{f}_{sig} = %0.03f", SignalFrac_3o2_3o3), "");
    bMass->AddEntry("NULL", Form("3.30 - 3.40 GeV/#it{c}^{2}, #it{f}_{sig} = %0.03f", SignalFrac_3o3_3o4), "");
    bMass->Draw();

    //========================================================
    //==================== SAVE ==============================
    //========================================================

    TString sFolSave2 = Form("OutputRoot/data/%s/invMassFit_%d_BkgFunc/",  sFolSave.Data(), !(isExpo));
    TString sFolPlot2 = Form("Plots/data/%s/invMassFit_%d_BkgFunc/", sFolSave.Data(), !(isExpo));
    gSystem->Exec(Form("mkdir -p %s", sFolSave2.Data()));
    gSystem->Exec(Form("mkdir -p %s", sFolPlot2.Data()));

    TH1F *hMass_Data_Scale = (TH1F *)hMass_Data->Clone("hMass_Data_Scale");
    hMass_Data_Scale->Scale(1. / hMass_Data->GetEntries());

    TFile *f1 = new TFile(Form("%s/data_invMassFit_pt_%0.02f_%0.02f.root", sFolSave2.Data(), ptMin, ptMax), "RECREATE");
    hMass_Data->Write();
    hMass_Data_Scale->Write("hMass_Data_Scale");
    fTotal->Write();
    fCrystalBall_Data->Write();
    fBkg->Write();

    params->Write("myParams_Data");
    parChi2ndf->Write("chi2ndf");
    paramSignalFrac->Write("myparam_SignalFrac");
    f1->Close();

    cout << " File saved at: " << sFolSave2.Data() << endl;
    c2->SaveAs(Form("%s/invMass_%0.02f_%0.02f.pdf", sFolPlot2.Data(), ptMin, ptMax));
}

Double_t EvaluateCrystallBall(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;

    double nCB = fPar[0];
    double mean = fPar[1];
    double sigma = fPar[2];
    double alpha = fPar[3];
    double n = fPar[4];

    ret = nCB * ROOT::Math::crystalball_function(m[0], alpha, n, sigma, mean);
    // https://github.com/root-project/root/blob/master/math/mathcore/inc/Math/PdfFuncMathCore.h

    return ret;
}
Double_t EvaluateExponential(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;
    double p0 = fPar[0];
    double p1 = fPar[1];
    double p2 = fPar[2];

    // ret = p0 * TMath::Exp(p1 + p2 * m[0]);
    ret = p0 * TMath::Exp(p2 * m[0]);

    return ret;
}
Double_t EvaluateGaussian(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;
    double p0 = fPar[0];
    double p1 = fPar[1];
    double p2 = fPar[2];

    ret = p0 * TMath::Gaus(m[0], p1, p2);
    return ret;
}
Double_t EvaluatePolynomial(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;
    double p0 = fPar[0];
    double p1 = fPar[1];
    double p2 = fPar[2];
    double p3 = fPar[3];
    double p4 = fPar[4];
    double p5 = fPar[5];

    ret = p0 + p1*m[0] + p2*m[0]*m[0] + p3*m[0]*m[0]*m[0]  + p4*m[0]*m[0]*m[0]*m[0]  + p5*m[0]*m[0]*m[0]*m[0]*m[0];
    return ret;
}
Double_t EvaluateCBplusGaus(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;

    double nCB = fPar[0];
    double mean = fPar[1];
    double sigma = fPar[2];
    double alpha = fPar[3];
    double n = fPar[4];

    double p0 = fPar[5];
    double p1 = fPar[6];
    double p2 = fPar[7];

    ret = nCB * ROOT::Math::crystalball_function(m[0], alpha, n, sigma, mean) + p0 * TMath::Gaus(m[0], p1, p2);

    return ret;
}
Double_t EvaluateCBplusExp(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;

    double nCB = fPar[0];
    double mean = fPar[1];
    double sigma = fPar[2];
    double alpha = fPar[3];
    double n = fPar[4];

    double p0 = fPar[5];
    double p1 = fPar[6];
    double p2 = fPar[7];

    // ret = nCB * ROOT::Math::crystalball_function(m[0], alpha, n, sigma, mean) + p0 * TMath::Exp(p1 + p2 * m[0]);
    ret = nCB * ROOT::Math::crystalball_function(m[0], alpha, n, sigma, mean) + p0 * TMath::Exp(p2 * m[0]);

    return ret;
}
Double_t EvaluateCBplusPolynomial(Double_t *m, Double_t *fPar)
{
    Double_t ret = 0;

    double nCB = fPar[0];
    double mean = fPar[1];
    double sigma = fPar[2];
    double alpha = fPar[3];
    double n = fPar[4];

    double p0 = fPar[5];
    double p1 = fPar[6];
    double p2 = fPar[7];
    double p3 = fPar[8];
    double p4 = fPar[9];
    double p5 = fPar[10];

    // ret = nCB * ROOT::Math::crystalball_function(m[0], alpha, n, sigma, mean) + p0 * TMath::Exp(p1 + p2 * m[0]);
    ret = nCB * ROOT::Math::crystalball_function(m[0], alpha, n, sigma, mean) + (p0 + p1*m[0] + p2*m[0]*m[0]  + p3*m[0]*m[0]*m[0]  + p4*m[0]*m[0]*m[0]*m[0]  + p5*m[0]*m[0]*m[0]*m[0]*m[0]);

    return ret;
}
