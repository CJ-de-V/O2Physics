//_________________________________________________________________________________________
//            Class to perform unbinned log-likelihood fit
//          Origin: Run-2 AliPhysics codes based on AliDielectronBtoJPSItoEle
// Contact: shreyasi.acharya@cern.ch; fiorella.fionda@cern.ch; Giuseppe.Bruno@cern.ch
//_________________________________________________________________________________________


#include "TROOT.h"
#include "TFile.h"
#include "TNtuple.h"
#include "TCanvas.h"
#include "TF1.h"
#include "TFitResult.h"
#include "TH1F.h"
#include "TLatex.h"
#include "TDatabasePDG.h"
#include "TString.h"
#include "TMath.h"
#include "TStopwatch.h"
#include "TMinuit.h"
#include "TKey.h"
#include "TFitter.h"
#include "TStyle.h"
#include "Math/MinimizerOptions.h"
#include "AddFunctionDefinition.C"

void SetStyle();
void Hist1DStyle(TH1F *h, int kMarker, float kMarkSize, int kColor, TString xTitle = "", TString yTitle = "");
void MakeReducedNtuple_New(std::vector<TString> &fileNames, TNtuple *ntNew, Double_t ptmin = 0., Double_t ptmax = 200., Double_t mMin1 = 2, Double_t mMax1 = 6., Int_t fAmbiIn = 9, Int_t fAmbiOut = 9, TH1F *h = 0x0, Bool_t isMC = false, Int_t iPlus = 1);
void ReadCandidates(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Bool_t *&ambiIn, Bool_t *&ambiOut, Bool_t *&CorrectAssoc, Int_t &ncand, Bool_t isMC = false);
Double_t ResolutionFunction(Double_t px, Double_t *par);
Double_t CallResolFunc(Double_t *x, Double_t *par);
Double_t ExpoPower(Double_t *px, Double_t *par);

void Fit_ResolutionMC()
{
    // SetStyle();
    Double_t massRangeMin = 2.0;
    Double_t massRangeMax = 3.5;

    Double_t ptBins[] = {0., 0.5, 1., 1.5, 2., 2.5, 3., 3.5, 4., 4.5, 5, 6, 7., 8, 10, 12, 15, 20};
    int kk = 10;
    Double_t ptMin = ptBins[kk];
    Double_t ptMax = ptBins[kk + 1];

    //========================================================
    //================== READ INPUT DATA =====================
    //========================================================

    std::vector<TString> fileNames;
    TString inputData;
    TString sFolOpen;
    //---------------------------------

    sFolOpen = "v7_4sigma_T367672";
    inputData = Form("InputFiles/");

    TString sFile1 = Form("%s/dileptonAOD_pMC_25b16.root", inputData.Data());
    fileNames.push_back(sFile1);

    //========================================================
    //================== DEFINE HISTOGRAMS ===================
    //========================================================
    float rangeResolHist = 8000;
    float rangeResolFit = 8000;

    int nRebin = 4;
    float nbinShift = 3;

    float nBinLowHist = (-1. * rangeResolHist) + nbinShift;
    float nBinHighHist = rangeResolHist + nbinShift;
    int nbinsHist = (nBinHighHist - nBinLowHist) / nRebin;
    float nbinWidth = (nBinHighHist - nBinLowHist) / nbinsHist;
    cout << " nbinWidth = " << nbinWidth << "   nBinLowHist = " << nBinLowHist << " nBinHighHist = " << nBinHighHist << endl;

    TH1F *hpromptLxy_MCp = new TH1F("promptMC_time", Form(""), nbinsHist, nBinLowHist, nBinHighHist);
    hpromptLxy_MCp->Sumw2();
    hpromptLxy_MCp->Rebin(1);
    if (kk == 0)
        hpromptLxy_MCp->Rebin(8);

    else if (kk == 1)
        hpromptLxy_MCp->Rebin(2);

    //--------------------PROMPT MC------------------------

    TNtuple *ntJPsi_MCp = new TNtuple("ntuple_new_MCp", "Ntuple_new_MCp", "Xdecaytime:Mass:Pt:ambiInBunch:ambiOutOfBunch");

    // MakeReducedNtuple_New(fileNames, ntJPsi_MCp, ptMin, ptMax, massRangeMin, massRangeMax, 9, 9, hpromptLxy_MCp, true, 1); //
    MakeReducedNtuple_New(fileNames, ntJPsi_MCp, ptMin, ptMax, massRangeMin, massRangeMax, 0, 0, hpromptLxy_MCp, true, 1); //

    TH1F *hpromptLxy_MCp_Clone = (TH1F *)hpromptLxy_MCp->Clone("hpromptLxy_MCp_Clone");

    //========================================================
    //================== FIT RESOLUTION FUNC =================
    //========================================================

    ROOT::Math::MinimizerOptions::SetDefaultMinimizer("Minuit");     // ("Minuit2,Migrad");
    ROOT::Math::MinimizerOptions::SetDefaultMaxIterations(10000000); // Increase max iterations
    ROOT::Math::MinimizerOptions::SetDefaultMaxFunctionCalls(10000000);

    Double_t entries = hpromptLxy_MCp->GetEntries();
    Double_t width = hpromptLxy_MCp->GetBinWidth(1);
    // int nParamaters = 9;
    int nParamaters = 10;
    TF1 *fitFunc_FromClass = new TF1("fitFunc_FromClass", CallResolFunc, -1. * rangeResolFit, rangeResolFit, nParamaters);
    fitFunc_FromClass->SetParameters(41.4195, 1, 473.964, 271.307, 1.65362, 155.771, 31.7058, 1.02025, 449442, entries * width);

    float rValX1 = -1000;
    float rValX2 = 1000;

    if (ptMin == 0.5)
    {
        rangeResolHist = 500;
        rangeResolFit = 2000;
        fitFunc_FromClass->SetParameters(195443, 0.359891, 30.0248, 500733, 2.71957, 54.7981, 95.002, 2, 72241.3, 30274.6);
        fitFunc_FromClass->SetParLimits(0, 1., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 1., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 1., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -30, 30);
        fitFunc_FromClass->SetParLimits(2, 15, 100);

        fitFunc_FromClass->SetParLimits(4, -20, 20);
        fitFunc_FromClass->SetParLimits(5, 1, 700);

        fitFunc_FromClass->SetParLimits(6, 1, 200);
        // fitFunc_FromClass->SetParLimits(7, 2.0, 3000);
        rValX1 = -3700;
        rValX2 = 3700;
    }
    if (ptMin == 1)
    {
        rangeResolHist = 500;
        rangeResolFit = 690;
        fitFunc_FromClass->SetParameters(993453, -2.84426, 53.1381, 947888, 8.85391, 99.2193, 126.804, 2.3006, 472386, 62596.9);
        fitFunc_FromClass->SetParLimits(0, 1., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 1., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 1., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -30, 30);
        fitFunc_FromClass->SetParLimits(2, 15, 100);

        fitFunc_FromClass->SetParLimits(4, -20, 20);
        fitFunc_FromClass->SetParLimits(5, 1, 700);

        fitFunc_FromClass->SetParLimits(6, 1, 200);
        fitFunc_FromClass->SetParLimits(7, 2.0, 3000);
        rValX1 = -1000;
        rValX2 = 1000;
    }
    if (ptMin == 1.5)
    {
        rangeResolHist = 500;
        rangeResolFit = 690;
        fitFunc_FromClass->SetParameters(993453, -2.84426, 53.1381, 947888, 8.85391, 99.2193, 126.804, 2.3006, 472386, 62596.9);
        fitFunc_FromClass->SetParLimits(0, 1., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 1., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 1., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -30, 30);
        fitFunc_FromClass->SetParLimits(2, 15, 100);

        fitFunc_FromClass->SetParLimits(4, -20, 20);
        fitFunc_FromClass->SetParLimits(5, 1, 700);

        fitFunc_FromClass->SetParLimits(6, 1, 200);
        fitFunc_FromClass->SetParLimits(7, 2.0, 3000);
        rValX1 = -1000;
        rValX2 = 1000;
    }
    if (ptMin == 2)
    {
        rangeResolHist = 500;
        rangeResolFit = 390;
        fitFunc_FromClass->SetParameters(376380, -0.366733, 31.2357, 54849.7, 10, 65.2323, 83.7862, 4.5, 89536.3, 28094.9);
        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -30, 30);
        fitFunc_FromClass->SetParLimits(2, 15, 100);

        fitFunc_FromClass->SetParLimits(4, -20, 20);
        fitFunc_FromClass->SetParLimits(5, 1, 700);

        fitFunc_FromClass->SetParLimits(6, 1, 200);
        fitFunc_FromClass->SetParLimits(7, 4.0, 3000);

        rValX1 = -500;
        rValX2 = 500;
    }
    if (ptMin == 2.5)
    {
        rangeResolHist = 500;
        rangeResolFit = 300;

        fitFunc_FromClass->SetParameters(357840, -0.124085, 20.3695, 712091, 0.195615, 37.4138, 55.3592, 2.51651, 151529, 26684.9);
        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -30, 30);
        fitFunc_FromClass->SetParLimits(2, 15, 100);

        fitFunc_FromClass->SetParLimits(4, -10, 10);
        fitFunc_FromClass->SetParLimits(5, 1, 70);

        fitFunc_FromClass->SetParLimits(6, 1, 200);
        fitFunc_FromClass->SetParLimits(7, 2.9, 3);

        rValX1 = -300;
        rValX2 = 300;
    }
    if (ptMin == 3)
    {
        rangeResolHist = 500;
        rangeResolFit = 180;

        fitFunc_FromClass->SetParameters(407909, 2.04035, 16.1174, 0, 0, 40, 29, 32.90387, 651727, 2964.5);
        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);
        rValX1 = -200;
        rValX2 = 200;
    }
    if (ptMin == 3.5)
    {
        rangeResolHist = 500;
        rangeResolFit = 210;

        fitFunc_FromClass->SetParameters(8803076, -0.976568, 21.2707, 3633630, 4.6878, 50, 28.872, 197.978, 2212708, 27077);
        fitFunc_FromClass->SetParLimits(0, 0., 1.e+12);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+12);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+12);

        fitFunc_FromClass->SetParLimits(1, -5, 5);
        fitFunc_FromClass->SetParLimits(2, 0., 200);
        fitFunc_FromClass->SetParLimits(4, -50., 50);
        fitFunc_FromClass->SetParLimits(5, 0., 50);

        // fitFunc_FromClass->SetParLimits(7, 1., 500);

        rValX1 = -300;
        rValX2 = 300;
    }

    else if (ptMin == 4)
    {
        rangeResolHist = 500;
        rangeResolFit = 200;
        fitFunc_FromClass->SetParameters(11.1241, 1.64911, 29.3945, 15.787, -0.657349, 15.8594, 39.796, 102.9, 4.13588, 34565.9);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParLimits(6, 4, 270);
        fitFunc_FromClass->SetParLimits(7, 4.0, 500);

        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 4.5)
    {
        rangeResolHist = 500;
        rangeResolFit = 190;
        fitFunc_FromClass->SetParameters(10.4399, -0.225003, 26.7745, 10.9847, 0.337897, 13.1165, 26.8771, 12.5, 3.56405, 52389);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParLimits(6, 4, 270);
        fitFunc_FromClass->SetParLimits(7, 4, 100);

        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 5)
    {
        rangeResolHist = 500;
        rangeResolFit = 190;
        // with TOF: 7.96051, 2.17293, 24.0471, 10.8078, 1.20042, 10.1975, 20.9999, 2.5, 15.4001, 3165.9
        fitFunc_FromClass->SetParameters(10.4427, -0.8752, 24.9272, 9.86798, 0.879541, 12.8361, 26.4186, 2.5, 4.26484, 26415.8);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParLimits(6, 4, 240);
        fitFunc_FromClass->SetParLimits(7, 3.9, 100);

        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 6)
    {
        rangeResolHist = 500;
        rangeResolFit = 190;
        fitFunc_FromClass->SetParameters(10.4427, -0.8752, 24.9272, 9.86798, 0.879541, 12.8361, 26.4186, 2.5, 4.26484, 26415.8);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParLimits(6, 4, 240);
        fitFunc_FromClass->SetParLimits(7, 2.9, 100);

        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 7)
    {
        rangeResolHist = 500;
        rangeResolFit = 190;
        fitFunc_FromClass->SetParameters(10.928, 0.274452, 20.1157, 15.0416, -0.495217, 10.3949, 19.1778, 25, 13.5713, 10805.);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParLimits(6, 4, 40);
        fitFunc_FromClass->SetParLimits(7, 2.1, 10);

        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 8)
    {
        rangeResolHist = 500;
        rangeResolFit = 190;
        // fitFunc_FromClass->SetParameters(5.14019, 6.80951, 24.2844, 21.1056, -0.226316, 11.1995, 21.372, 2.5, 10.4781, 10575.1);
        fitFunc_FromClass->SetParameters(5.14019, 6.80951, 24.2844, 21.1056, -0.226316, 11.1995, 21.372, 2.7, 10.4781, 10575.1);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParameter(6, 0.);
        fitFunc_FromClass->SetParLimits(6, 1, 40);
        fitFunc_FromClass->SetParLimits(7, 2.7, 10);
        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 10)
    {
        rangeResolHist = 500;
        rangeResolFit = 150;
        // 100.837, 1.87927, 25.2623, 199.247, -0.444973, 11.9396, 5.00004, 10, 3.27516e-09, 7981.53
        fitFunc_FromClass->SetParameters(87.9272, 1.16692, 20.8291, 117.326, -0.807366, 9.7099, 5.00024, 9.99998, 3.47281, 4325.96);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 1., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -100., 100.);
        fitFunc_FromClass->SetParLimits(2, 0., 100.);

        fitFunc_FromClass->SetParLimits(4, -100., 100.);
        fitFunc_FromClass->SetParLimits(5, 3, 100.);

        fitFunc_FromClass->SetParLimits(6, 4, 400);
        fitFunc_FromClass->SetParLimits(7, 2.0, 100);

        rValX1 = -300;
        rValX2 = 300;
    }
    else if (ptMin == 12)
    {
        rangeResolHist = 500;
        rangeResolFit = 150;
        // 47.4413, 1.05511, 16.1574, 49.5083, -0.937516, 8.65308, 26.1113, 2, 17.4075, 4480.86
        fitFunc_FromClass->SetParameters(0.845332, -0.867063, 16.3787, 34.1768, -0.69024, 11.0483, 18.0723, 15.0001, 10.8054, 2372.21);

        fitFunc_FromClass->SetParLimits(0, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(3, 0., 1.e+06);
        fitFunc_FromClass->SetParLimits(8, 0., 1.e+06);

        fitFunc_FromClass->SetParLimits(1, -10., 10.);
        fitFunc_FromClass->SetParLimits(2, 1., 17.);

        fitFunc_FromClass->SetParLimits(4, -10., 10.);
        fitFunc_FromClass->SetParLimits(5, 3, 10.);

        fitFunc_FromClass->SetParLimits(6, 1, 190);
        fitFunc_FromClass->SetParLimits(7, 2.7, 4);

        rValX1 = -200;
        rValX2 = 200;
    }

    TFitResultPtr rFitRes_1 = hpromptLxy_MCp_Clone->Fit(fitFunc_FromClass->GetName(), "S0", "", -1. * rangeResolFit, rangeResolFit);
    TF1 *funcFromFit = (TF1 *)(hpromptLxy_MCp_Clone->GetListOfFunctions())->At(0);
    funcFromFit->SetNpx(100000);
    int fitStatus = rFitRes_1; /// Convert to int
    double chi2 = rFitRes_1->Chi2();
    double ndf = rFitRes_1->Ndf();
    double chi2_ndf = chi2 / ndf;

    cout << " chi2/ndf = " << chi2 << "/" << ndf << " = " << chi2_ndf << endl;

    TVectorD *chi2ndfVector = new TVectorD(3);
    (*chi2ndfVector)[0] = chi2;
    (*chi2ndfVector)[1] = ndf;
    (*chi2ndfVector)[2] = chi2_ndf;

    //========================================================
    //========================== DRAW ========================
    //========================================================

    TCanvas *c1 = new TCanvas("c1", "Resolution Function", 800, 600);
    c1->cd();
    c1->SetRightMargin(0.01738123);
    c1->SetTopMargin(0.02608695);
    c1->SetLogy();
    Hist1DStyle(hpromptLxy_MCp, 20, 1., kBlack, "Pseudoproper decay time (x) in #mum", "Entries");
    hpromptLxy_MCp->SetLineWidth(3);
    hpromptLxy_MCp->GetXaxis()->SetRangeUser(rValX1, rValX2);
    hpromptLxy_MCp->Draw("PE");
    funcFromFit->SetLineWidth(6);
    funcFromFit->Draw("same");
    TF1 *fcomp1Gaus = new TF1("Gaus1", "gaus", -1. * rangeResolFit, rangeResolFit);
    fcomp1Gaus->SetParameters(funcFromFit->GetParameter(0) * funcFromFit->GetParameter(9) / (TMath::Sqrt(2 * TMath::Pi()) * funcFromFit->GetParameter(2) * (funcFromFit->GetParameter(0) + funcFromFit->GetParameter(3) + funcFromFit->GetParameter(8))), funcFromFit->GetParameter(1), funcFromFit->GetParameter(2));
    fcomp1Gaus->SetLineColor(kOrange);
    fcomp1Gaus->SetNpx(100000);

    TF1 *fcomp2Gaus = new TF1("Gaus2", "gaus", -1. * rangeResolFit, rangeResolFit);
    fcomp2Gaus->SetParameters(funcFromFit->GetParameter(3) * funcFromFit->GetParameter(9) / (TMath::Sqrt(2 * TMath::Pi()) * funcFromFit->GetParameter(5) * (funcFromFit->GetParameter(0) + funcFromFit->GetParameter(3) + funcFromFit->GetParameter(8))), funcFromFit->GetParameter(4), funcFromFit->GetParameter(5));
    fcomp2Gaus->SetLineColor(kMagenta);
    fcomp2Gaus->SetNpx(100000);

    TF1 *fcomp3ExpoPower = new TF1("ExpoPower", ExpoPower, -1. * rangeResolFit, rangeResolFit, 3);
    fcomp3ExpoPower->SetParameters(funcFromFit->GetParameter(6), funcFromFit->GetParameter(7), funcFromFit->GetParameter(8) * funcFromFit->GetParameter(9) / (funcFromFit->GetParameter(0) + funcFromFit->GetParameter(3) + funcFromFit->GetParameter(8)));
    fcomp3ExpoPower->SetLineColor(kGreen + 1);
    fcomp3ExpoPower->SetNpx(100000);

    fcomp3ExpoPower->Draw("same");
    fcomp2Gaus->Draw("same");
    fcomp1Gaus->Draw("same");
    hpromptLxy_MCp->Draw("PE same");

    //========================================================

    cout << " Entries " << hpromptLxy_MCp->GetEntries() << endl;
    double intgFromFunc = funcFromFit->Integral(-8000., 8000.);
    double paramFromFunc = funcFromFit->GetParameter(9);
    double intgbynorm = intgFromFunc / paramFromFunc;
    cout << " integral  = " << intgFromFunc << " global norm. = " << paramFromFunc << " integral function / global normalisation -> " << intgbynorm << endl;

    TVectorD *intgNorm = new TVectorD(3);
    (*intgNorm)[0] = intgFromFunc;
    (*intgNorm)[1] = paramFromFunc;
    (*intgNorm)[2] = intgbynorm;

    //========================================================

    TLegend *bResol = new TLegend(0.1478697, 0.786087, 0.3483709, 0.9217391);
    bResol->SetTextSize(0.037);
    bResol->SetBorderSize(0);
    bResol->AddEntry("NULL", Form("%0.02f < #it{p}^{ee}_{T} < %0.02f GeV/#it{c}", ptMin, ptMax), "hc");
    bResol->AddEntry("NULL", Form("#chi^{2}/ndf = %0.0f/%0.0f = %0.02f", chi2, ndf, chi2_ndf), "hc");
    bResol->AddEntry("NULL", Form("Fit status = %d", fitStatus), "hc");
    bResol->Draw();

    TLegend *bResol1 = new TLegend(0.09649123, 0.4730435, 0.3195489, 0.7530435);
    bResol1->SetTextSize(0.03);
    bResol1->SetFillStyle(0);
    bResol1->SetBorderSize(0);
    bResol1->AddEntry("NULL", Form("Gaus1 Norm = %0.0f", funcFromFit->GetParameter(0)), "");
    bResol1->AddEntry("NULL", Form("Gaus1 Mean = %0.02f", funcFromFit->GetParameter(1)), "");
    bResol1->AddEntry("NULL", Form("Gaus1 #sigma = %0.02f", funcFromFit->GetParameter(2)), "");
    bResol1->AddEntry("NULL", Form("Gaus2 Norm = %0.0f", funcFromFit->GetParameter(3)), "");
    bResol1->AddEntry("NULL", Form("Gaus2 Mean = %0.02f", funcFromFit->GetParameter(4)), "");
    bResol1->AddEntry("NULL", Form("Gaus2 #sigma = %0.02f", funcFromFit->GetParameter(5)), "");
    bResol1->AddEntry("NULL", Form("Pow #alpha = %0.02f", funcFromFit->GetParameter(6)), "");
    bResol1->AddEntry("NULL", Form("Pow #lambda = %0.02f", funcFromFit->GetParameter(7)), "");
    bResol1->AddEntry("NULL", Form("Pow Norm = %0.0f", funcFromFit->GetParameter(8)), "");
    bResol1->AddEntry("NULL", Form("Global Norm = %0.0f", funcFromFit->GetParameter(9)), "");
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(0))->SetTextColor(kOrange);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(1))->SetTextColor(kOrange);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(2))->SetTextColor(kOrange);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(3))->SetTextColor(kMagenta);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(4))->SetTextColor(kMagenta);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(5))->SetTextColor(kMagenta);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(6))->SetTextColor(kGreen + 1);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(7))->SetTextColor(kGreen + 1);
    static_cast<TLegendEntry *>(bResol1->GetListOfPrimitives()->At(8))->SetTextColor(kGreen + 1);
    bResol1->Draw();

    TLegend *bResol2 = new TLegend(0.3446115, 0.9321739, 0.5676692, 0.9669565);
    bResol2->SetTextSize(0.03);
    bResol2->SetFillStyle(0);
    bResol2->SetBorderSize(0);
    bResol2->AddEntry("NULL", Form("integral of full func / Global Norm = %0.02f", intgbynorm), "");
    bResol2->Draw();

    //========================================================
    //==================== SAVE ==============================
    //========================================================

    TVectorD *params = new TVectorD(nParamaters);
    for (int ii = 0; ii < nParamaters; ii++)
    {
        (*params)[ii] = funcFromFit->GetParameter(ii);
        cout << (*params)[ii] << ", ";
    }
    cout << endl;

    TString sFolSave2 = Form("OutputRoot/pMC/Resolution/%s/", sFolOpen.Data());
    TString sFolPlot2 = Form("Plots/pMC/Resolution/%s/", sFolOpen.Data());
    gSystem->Exec(Form("mkdir -p %s", sFolSave2.Data()));
    gSystem->Exec(Form("mkdir -p %s", sFolPlot2.Data()));

    TH1F *hpromptLxy_MCp_Scale = (TH1F *)hpromptLxy_MCp->Clone("hpromptLxy_MCp_Scale");
    hpromptLxy_MCp_Scale->Scale(1. / hpromptLxy_MCp->GetEntries());

    TFile *f1 = new TFile(Form("%s/output_pt_%0.02f_%0.02f.root", sFolSave2.Data(), ptMin, ptMax), "RECREATE");
    funcFromFit->Write("fResol_MCp");
    hpromptLxy_MCp->Write("hpromptLxy_MCp");
    hpromptLxy_MCp_Scale->Write("hpromptLxy_MCp_Scale");
    fcomp1Gaus->Write();
    fcomp2Gaus->Write();
    fcomp3ExpoPower->Write();
    params->Write("myParams");
    chi2ndfVector->Write("chi2ndfVector");
    intgNorm->Write("intgNorm");
    f1->Close();
    cout << " File saved as: " << sFolSave2.Data() << endl;

    c1->SaveAs(Form("%s/resol_pt_%0.02f_%0.02f.pdf", sFolPlot2.Data(), ptMin, ptMax));
}

Double_t CallResolFunc(Double_t *x, Double_t *par)
{
    double ret = ResolutionFunction(x[0], par);
    return ret * par[9];
}

Double_t ExpoPower(Double_t *px, Double_t *par)
{
    Double_t alfa = par[0];
    Double_t lambda = par[1];
    Double_t norm3 = par[2];

    Double_t x = px[0];
    Double_t fitval = 0.;

    if (TMath::Abs(x) <= alfa)
        fitval = (lambda - 1) / (2 * alfa * lambda);
    else
        fitval = ((lambda - 1) / (2 * alfa * lambda)) * TMath::Power(alfa, lambda) * (TMath::Power(TMath::Abs(x), -1 * lambda));

    double ret = norm3 * fitval;
    return ret;
}

/*
    TCanvas *c4 = new TCanvas("c4", "c4", 712, 200, 800, 466);
    TH1F *hMirror1 = new TH1F("hMirror1", "", nbinsHist, nBinLowHist, nBinHighHist);
    TH1F *hMirror2 = new TH1F("hMirror2", "", nbinsHist, nBinLowHist, nBinHighHist);

    for (int ii = 1; ii <= hpromptLxy_MCp->GetNbinsX(); ii++)
    {
        float ibinCentre = hpromptLxy_MCp->GetBinCenter(ii);
        if (ibinCentre < 0)
        {
            int imirBin = hMirror1->FindBin(-1 * ibinCentre);
            // cout << ii << "  " << imirBin << "  ibinCentre = " << ibinCentre << endl;
            hMirror1->SetBinContent(imirBin, hpromptLxy_MCp->GetBinContent(ii));
            hMirror1->SetBinError(imirBin, hpromptLxy_MCp->GetBinError(ii));
        }
        else if (ibinCentre >= 0)
        {
            int imirBin = hMirror2->FindBin(ibinCentre);
            hMirror2->SetBinContent(imirBin - 1, hpromptLxy_MCp->GetBinContent(ii));
            hMirror2->SetBinError(imirBin - 1, hpromptLxy_MCp->GetBinError(ii));
            // cout << ii << "  " << imirBin << "  ibinCentre = " << ibinCentre << endl;
        }
    }
    // hMirror1->Draw();
    // hMirror2->Draw("same");
    TH1F *hMirrorRatio = (TH1F *)hMirror2->Clone("h-Mirrored-Ratio");
    hMirrorRatio->Divide(hMirror2, hMirror1, 1., 1., "B");
    hMirrorRatio->GetXaxis()->SetRangeUser(0, nBinHighHist);
    hMirrorRatio->GetYaxis()->SetRangeUser(0.01, 9);
    hMirrorRatio->SetLineColor(kAzure);
    hMirrorRatio->SetMarkerColor(kAzure);
    hMirrorRatio->SetMarkerStyle(20);
    hMirrorRatio->Draw("same");

    TLine *l1 = new TLine(0, 1., nBinHighHist, 1);
    l1->SetLineStyle(5);
    l1->SetLineColor(kBlack);
    l1->Draw("same");
    */