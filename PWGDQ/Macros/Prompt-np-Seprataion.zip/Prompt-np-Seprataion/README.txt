
- In "AddFunctionDefinition.C" we have all the important function that are called by the following .C codes.
- InputFiles had the trees from data, prompt-MC and non-prompt MC. 
==============================================================================================
Step 1:

Fit the ee-invarainat mass of data in JPsi-region (attached in the folder is 2024 pass1 pp data at 13.6 TeV)

    =>  root -l "Fit_JpsiMass.C(10, kFALSE)" 
        => Uses dilpetonAOD.root from data, obtained after running on table-reader
        => Argument "10" is the for pT bins and the bool is to allow for exponenetial bkg or not!

    => .root file and pdf automatically saved

==============================================================================================
Step 2:

Fit the resolution function, i.e., the pseudoproper decay length of prompt JPsi from prompt MC sample 

    => root -l Fit_ResolutionMC.C 
        => Uses dilpetonAOD.root from the 25b16 which is  prompt enhnaced MC for JPsi, obtained after running on table-reader-MC
        => Change the pT intervals inside the code
     => .root file and pdf automatically saved
==============================================================================================
Step 3:

Fit the the pseudoproper decay length from data, in background region
     => root -l 
       > .L Fit_BkgData.C++
       > Fit_BkgData(10, 3.20, 3.40, 0, 0, 1)

    => Uses dilpetonAOD.root from data, and the resolution function from step 2!
    => .root file and pdf automatically saved
    => For a faster run, you could increase the last paramater from 1 to anything, the larger number, the less data processed, faster

==============================================================================================
Step 4:


2-dimentional likehood fit the the pseudoproper decay length from data in signal region
     => root -l 
       > .L Fit_Convl_2D.C++
       > Fit_Convl_2D(10, 1, 3.20, 3.40, 0, 0, 2.4, 3.2, 1)

    => Uses:
         -> dilpetonAOD.root from data for signal region,
         -> ee-invariant data mass fit from step 1, 
         -> background function fit from step 3,
         -> dilpetonAOD.root from np-MC (I have a several files as I ran them separately)
    => .root file and pdf automatically saved
    => For a faster run, you could increase the last paramater from 1 to anything, the larger number, the less data processed, faster


