//_________________________________________________________________________________________
//            Class to perform unbinned log-likelihood fit
//          Origin: Run-2 AliPhysics codes based on AliDielectronBtoJPSItoEle
// Contact: shreyasi.acharya@cern.ch; fiorella.fionda@cern.ch; Giuseppe.Bruno@cern.ch
//_________________________________________________________________________________________


#include "TROOT.h"
#include "TSystem.h"
#include "TFile.h"
#include "TNtuple.h"
#include "TCanvas.h"
#include "TF1.h"
#include "TFitResult.h"
#include "TH1F.h"
#include "TLatex.h"
#include "TDatabasePDG.h"
#include "TString.h"
#include "TMath.h"
#include "TStopwatch.h"
#include "TMinuit.h"
#include "TKey.h"
#include "TFitter.h"
#include "TStyle.h"
#include "TFFTReal.h"
#include "TMath.h"
#include "TComplex.h"
#include "Math/MinimizerOptions.h"
#include "TVectorT.h"
#include "AddFunctionDefinition.C"

void SetStyle();
void Hist1DStyle(TH1F *h, int kMarker, float kMarkSize, int kColor, TString xTitle = "", TString yTitle = "");
void MakeReducedNtuple_New(std::vector<TString> &fileNames, TNtuple *ntNew, Double_t ptmin = 0., Double_t ptmax = 200., Double_t mMin1 = 2, Double_t mMax1 = 6., Int_t fAmbiIn = 9, Int_t fAmbiOut = 9, TH1F *h = 0x0, Bool_t isMC = false, Int_t iPlus = 1);
void ReadCandidates(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Bool_t *&ambiIn, Bool_t *&ambiOut, Bool_t *&CorrectAssoc, Int_t &ncand, Bool_t isMC = false);
void ReadAndReduceCandidates(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Bool_t *&ambiIn, Bool_t *&ambiOut, Bool_t *&CorrectAssoc, Int_t &ncand, Double_t ptmin = 0., Double_t ptmax = 200., Double_t mMin1 = 2, Double_t mMax1 = 6., Bool_t isMC = false);

Double_t ResolutionFunction(double x, double *);
Double_t FunBkgPos(Double_t x, Double_t *);
Double_t FunBkgNeg(Double_t x, Double_t *);
Double_t FunBkgSym(Double_t x, Double_t *);
Double_t FunBkgSym1(Double_t x, Double_t *);
Double_t EvaluateCDFDecayTimeBkgDistr(Double_t x, Double_t *);
Double_t EvaluateLikelihood(const Double_t *pseudoproperdecaytime, Int_t ncand, Double_t *par);
void CdfFCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag);
void CDFFunction(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag);
Int_t DoMinimization(Double_t *);
Double_t CDFBkgFunction(Double_t *x, Double_t *par);
Double_t CDFBkgFunctionForDrawing(Double_t *x, Double_t *par);
Double_t CallPosFunc(Double_t *x, Double_t *par);
Double_t CallNegFunc(Double_t *x, Double_t *par);
Double_t CallSymFunc(Double_t *x, Double_t *par);
Double_t CallSym1Func(Double_t *x, Double_t *par);
Double_t CallResolFunc(Double_t *x, Double_t *par);

Double_t *fX = 0x0;
Int_t nCand;
Double_t fValPar[18];

void Fit_BkgData(int kk = 10, Double_t massBkgMin1 = 3.20, Double_t massBkgMax1 = 3.40, Double_t massBkgMin2 = 0, Double_t massBkgMax2 = 0, Int_t iSkip = 10)
{
   

    Double_t ptBins[] = {0., 0.5, 1., 1.5, 2., 2.5, 3., 3.5, 4., 4.5, 5, 6, 7., 8, 10, 12, 15, 20};
    Double_t ptMin = ptBins[kk];
    Double_t ptMax = ptBins[kk + 1];

    //========================================================
    //================== READ INPUT DATA =====================
    //========================================================

    std::vector<TString> fileNames;
    TString sFolder;
    TString inputData;
    TFile *fResol;
    TString sFolOpenpMC;
    TString sSubFolSave;

    sFolOpenpMC = "v7_4sigma_T367672";
    sSubFolSave = "v7_4sigma_data_2024";
    inputData = Form("InputFiles/");

    
    //-------------DATA IN BACKGROUND----------
    TString sFile1 = Form("%s/dileptonAOD_Data_24pass1_4sigma.root", inputData.Data());
    fileNames.push_back(sFile1);

    //-------------RESOLUTION pMC----------
    TString sFilepMC = Form("OutputRoot/pMC/Resolution/%s/output_pt_%0.02f_%0.02f.root", sFolOpenpMC.Data(), ptMin, ptMax);
    fResol = TFile::Open(Form("%s", sFilepMC.Data()));

    cout << " Opened: " << sFile1.Data() << " " << sFilepMC.Data() << endl;

    //========================================================
    //================== DATA IN BACKGROUND ==================
    //========================================================

    float rangeResolFitMin = -3000;
    float rangeResolFitMax = 3000;
    float rangeResolBin = rangeResolFitMax - rangeResolFitMin;
    double factor = 0.25;

    //-------------DATA IN BACKGROUND----------

    TNtuple *ntJPsi_DataBkg = new TNtuple("ntJPsi_DataBkg", "ntJPsi_DataBkg", "Xdecaytime:Mass:Pt:ambiInBunch:ambiOutOfBunch");
    TH1F *hpromptLxy_DataBkg = new TH1F("promptDataBkg_time", Form(""), rangeResolBin * factor, rangeResolFitMin, rangeResolFitMax);
    hpromptLxy_DataBkg->Sumw2();
    MakeReducedNtuple_New(fileNames, ntJPsi_DataBkg, ptMin, ptMax, massBkgMin1, massBkgMax1, 9, 9, hpromptLxy_DataBkg, false, iSkip);
    MakeReducedNtuple_New(fileNames, ntJPsi_DataBkg, ptMin, ptMax, massBkgMin2, massBkgMax2, 9, 9, hpromptLxy_DataBkg, false, iSkip);

    Double_t *pseudoproperTime = 0x0;
    Double_t *pseudoproperTime_Cut = 0x0;
    Double_t *mass = 0x0;
    Double_t *pt = 0x0;
    Bool_t *CorrAssocRecoMCnp = 0x0;
    Bool_t *ambIn = 0x0;
    Bool_t *ambOut = 0x0;
    Bool_t *corrA = 0x0;

    ReadCandidates(ntJPsi_DataBkg, pseudoproperTime, mass, pt, ambIn, ambOut, corrA, nCand, false); // read N-Tuples from Data-Bkg

    //========================================================
    //======================= GET PARAMETERS =================
    //========================================================

    TVectorD *params = (TVectorD *)fResol->Get("myParams");
    for (int ii = 0; ii < 9; ii++)
        cout << (*params)(ii) << ", ";
    cout << endl;

    Double_t fParam[] = {
        (*params)(0),
        (*params)(1),
        (*params)(2),
        (*params)(3),
        (*params)(4),
        (*params)(5),
        (*params)(6),
        (*params)(7),
        (*params)(8),
        3, // nTotlresol
        0.312123,
        0.494183,
        0.012645,
        2.1655,
        0.00271712,
        0.00359621,
        0.0005,
        0.0136572};

    Int_t numElements = sizeof(fParam) / sizeof(Double_t);

    //========================================================
    //======================= MINIMIZE =======================
    //========================================================

    fX = new Double_t[nCand];
    fX = pseudoproperTime;

    DoMinimization(fParam);

    //========================================================
    //======================= HISTOGRAM ======================
    //========================================================

    float rangeMassHistoLow = 2.0;
    float rangeMassHistoHigh = 3.5;
    double nbinsMass = 50;
    double binWidth = (rangeMassHistoHigh - rangeMassHistoLow) / nbinsMass;

    TH1F *hData_InvMass = new TH1F("inv mass data", Form("inv mass data"), nbinsMass, rangeMassHistoLow, rangeMassHistoHigh);
    hData_InvMass->Sumw2();
    for (Int_t i = 0; i < nCand; i++)
        hData_InvMass->Fill(mass[i]);

    //========================================================
    //========================= RANGE SET ====================
    //========================================================

    float rXval1 = -1500;
    float rXval2 = 1500;

    if (kk == 4)
    {
        rXval1 = -500;
        rXval2 = 500;
    }
    //========================================================
    //========================= DRAW =========================
    //========================================================
    TCanvas *c2 = new TCanvas("c2", "Background Data ", 800, 600);
    c2->cd();
    c2->SetLogy();
    Hist1DStyle(hpromptLxy_DataBkg, 20, 1., kBlack, "Pseudoproper decay time (x) in #mum", Form("Entries/%1.1f #mum", 2. / factor));
    hpromptLxy_DataBkg->SetLineWidth(3);
    hpromptLxy_DataBkg->GetXaxis()->SetRangeUser(rXval1, rXval2);
    hpromptLxy_DataBkg->Draw("PE");

    TF1 *psProperBack = new TF1("psProperBack", CDFBkgFunctionForDrawing, -1000, 2000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        printf("val Par %d -> %f \n", ii, fValPar[ii]);
        psProperBack->FixParameter(ii, fValPar[ii]);
    }
    cout << hpromptLxy_DataBkg->GetEntries() << endl;
    cout << hpromptLxy_DataBkg->GetBinWidth(1) << endl;
    cout << hpromptLxy_DataBkg->GetEntries() * hpromptLxy_DataBkg->GetBinWidth(1) << endl;
    psProperBack->SetParameter(numElements, 122608.32);
    // psProperBack->SetParLimits(numElements, 122608.0, 172608.0);
    TFitResultPtr rPsproper = hpromptLxy_DataBkg->Fit("psProperBack", "S0");
    psProperBack->SetLineColor(kRed);
    psProperBack->SetNpx(500); //
    psProperBack->Draw("same l");

    TF1 *fPosFunc = new TF1("CallPosFunc", CallPosFunc, -1000, 1000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fPosFunc->SetParameter(ii, fValPar[ii]);
    }
    fPosFunc->SetParameter(numElements, rPsproper->Parameter(18));
    fPosFunc->SetLineColor(kGreen);
    fPosFunc->SetNpx(500); //
    fPosFunc->Draw("same l");

    TF1 *fNegFunc = new TF1("CallNegFunc", CallNegFunc, -1000, 1000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fNegFunc->SetParameter(ii, fValPar[ii]);
    }
    fNegFunc->SetParameter(numElements, rPsproper->Parameter(18));
    fNegFunc->SetLineColor(kGreen);
    fNegFunc->SetNpx(500); //
    fNegFunc->Draw("same l");

    TF1 *fSymFunc = new TF1("fSymFunc", CallSymFunc, -1000, 1000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fSymFunc->SetParameter(ii, fValPar[ii]);
    }
    fSymFunc->SetParameter(numElements, rPsproper->Parameter(18));
    fSymFunc->SetLineColor(kBlue);
    fSymFunc->SetNpx(500); //
    fSymFunc->Draw("same l");

    TF1 *fSym1Func = new TF1("fSym1Func", CallSym1Func, -1000, 1000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fSym1Func->SetParameter(ii, fValPar[ii]);
    }
    fSym1Func->SetParameter(numElements, rPsproper->Parameter(18));
    fSym1Func->SetLineColor(kGreen + 2);
    fSym1Func->Draw("same l");

    TF1 *fResolFunc = new TF1("fResolFunc", CallResolFunc, -1000, 1000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fResolFunc->SetParameter(ii, fValPar[ii]);
    }
    fResolFunc->SetParameter(numElements, rPsproper->Parameter(18));
    fResolFunc->SetLineColor(kOrange + 2);
    fResolFunc->SetNpx(500); //
    fResolFunc->Draw("same l");

    TLatex *latPs = new TLatex;
    latPs->SetNDC(kTRUE);
    latPs->SetTextColor(1);
    latPs->SetTextFont(42);
    latPs->SetTextSize(.035);
    latPs->DrawLatex(0.153, 0.82, Form("#chi^{2}/dof = %4.3f ", (rPsproper->Chi2() / (Double_t)rPsproper->Ndf())));
    latPs->DrawLatex(0.153, 0.72, Form("#it{p}_{T}: %0.2f - %0.2f", ptMin, ptMax));
    latPs->DrawLatex(0.153, 0.62, Form("#it{m}_{ee}: %0.2f - %0.2f + %0.2f - %0.2f", massBkgMin2, massBkgMax2, massBkgMin1, massBkgMax1));
    latPs->Draw();

    int nParamaters = 18;
    TVectorD *paramsBkg = new TVectorD(nParamaters);
    for (int ii = 0; ii < nParamaters; ii++)
    {
        (*paramsBkg)[ii] = psProperBack->GetParameter(ii);
        cout << (*paramsBkg)[ii] << ", ";
    }
    cout << endl;

    TVectorD *chi2ndfVector = new TVectorD(3);
    (*chi2ndfVector)[0] = rPsproper->Chi2();
    (*chi2ndfVector)[1] = rPsproper->Ndf();
    (*chi2ndfVector)[2] = (rPsproper->Chi2() / rPsproper->Ndf());
    cout << " chi2/ndf = " << (*chi2ndfVector)[0] << "/" << (*chi2ndfVector)[1] << " = " << (*chi2ndfVector)[2] << endl;

    //========================================================
    //==================== SAVE ==============================
    //========================================================

    TString sFolSave2 = Form("OutputRoot/data/%s/OutputBkgFit/mass_%0.02f_%0.02f_%0.02f_%0.02f/", sSubFolSave.Data(), massBkgMin2, massBkgMax2, massBkgMin1, massBkgMax1);
    TString sFolPlot2 = Form("Plots/data/%s/OutputBkgFit/mass_%0.02f_%0.02f_%0.02f_%0.02f/", sSubFolSave.Data(), massBkgMin2, massBkgMax2, massBkgMin1, massBkgMax1);
    gSystem->Exec(Form("mkdir -p %s", sFolSave2.Data()));
    gSystem->Exec(Form("mkdir -p %s", sFolPlot2.Data()));

    TFile *f1 = new TFile(Form("%s/bkgfunc_pt_%0.02f_%0.02f.root", sFolSave2.Data(), ptMin, ptMax), "RECREATE");
    hpromptLxy_DataBkg->Write();
    hData_InvMass->Write();
    psProperBack->Write();
    fPosFunc->Write();
    fNegFunc->Write();
    fSymFunc->Write();
    fSym1Func->Write();
    fResolFunc->Write();
    paramsBkg->Write("paramsBkg");
    chi2ndfVector->Write("chi2ndfVector");

    f1->Close();

    cout << "File saved at:" << sFolSave2.Data() << endl;

    c2->SaveAs(Form("%s/bkgfunc_pt_%0.02f_%0.02f.pdf", sFolPlot2.Data(), ptMin, ptMax));
}
Double_t CDFBkgFunction(Double_t *x, Double_t *par)
{
    double ret = EvaluateCDFDecayTimeBkgDistr(x[0], par);
    return ret;
}
Double_t CDFBkgFunctionForDrawing(Double_t *x, Double_t *par)
{
    double ret = EvaluateCDFDecayTimeBkgDistr(x[0], par);
    return ret * par[18];
}
Double_t CallResolFunc(Double_t *x, Double_t *par)
{
    double ret = par[9] * ResolutionFunction(x[0], par) / (par[9] + par[10] + par[11] + par[12] + par[13]);
    return ret * par[18];
}
Double_t CallPosFunc(Double_t *x, Double_t *par)
{
    double ret = par[10] * FunBkgPos(x[0], par) / (par[9] + par[10] + par[11] + par[12] + par[13]);
    return ret * par[18];
}
Double_t CallNegFunc(Double_t *x, Double_t *par)
{
    double ret = par[11] * FunBkgNeg(x[0], par) / (par[9] + par[10] + par[11] + par[12] + par[13]);
    return ret * par[18];
}
Double_t CallSymFunc(Double_t *x, Double_t *par)
{
    double ret = par[12] * FunBkgSym(x[0], par) / (par[9] + par[10] + par[11] + par[12] + par[13]);
    return ret * par[18];
}
Double_t CallSym1Func(Double_t *x, Double_t *par)
{
    double ret = par[13] * FunBkgSym1(x[0], par) / (par[9] + par[10] + par[11] + par[12] + par[13]);
    return ret * par[18];
}

Double_t EvaluateLikelihood(Double_t *pseudoproperdecaytime, Int_t ncand, Double_t *par) // This function evaluates the Likelihood fnction. It returns the -Log(of the likelihood function)
{
    Double_t f = 0.;
    Double_t ret = 0.;

    for (Int_t i = 0; i < ncand; i++)
    {
        if (pseudoproperdecaytime[i] < -9999.)
            continue;
        f = EvaluateCDFDecayTimeBkgDistr(pseudoproperdecaytime[i], par);

        // printf("xi %f \n",pseudoproperdecaytime[i]);
        if (f <= 0.)
            continue;
        ret += -2. * TMath::Log(f);
    }
    return ret;
}

void CdfFCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{
    // This function is called by minuit
    // The corresponding member method is called
    // using SetObjectFit/GetObjectFit methods of TMinuit
    TStopwatch t;
    t.Start();
    f = EvaluateLikelihood(fX, nCand, par);
    // for(int icand=0; icand < nCand; icand++) printf(" val %f \n",fX[icand]);
    TVirtualFitter::GetFitter()->GetObjectFit();
    t.Stop();

    cout << "Real time spent to calculate function == " << t.RealTime() << "  \n";
    cout << "CPU time spent to calculate function == " << t.CpuTime() << "  \n";
}

void CDFFunction(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{
    CdfFCN(npar, gin, f, par, iflag);
}

Int_t DoMinimization(Double_t *fPar) // performs the minimization
{
    TObject *obj = new TObject(); // Create an object (or use an existing one)
    TFitter *fitter = (TFitter *)TVirtualFitter::Fitter(obj, 18);
    fitter->SetFCN(CDFFunction);

    fitter->SetParameter(0, "resol_norm1", fPar[0], 1.e-10, 0., 1.e+06);
    fitter->SetParameter(1, "resol_mean1", fPar[1], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(2, "resol_sigma1", fPar[2], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(3, "resol_norm2", fPar[3], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(4, "resol_mean2", fPar[4], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(5, "resol_sigma2", fPar[5], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(6, "resol_alfa", fPar[6], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(7, "resol_lambd", fPar[7], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(8, "resol_norm3", fPar[8], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(9, "nTotlresol", fPar[9], 1.e-8, 2.6, 1.e+06);

    fitter->SetParameter(10, "f_plus", fPar[10], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(11, "f_minus", fPar[11], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(12, "f_Sym", fPar[12], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(13, "f_Sym1", fPar[13], 1.e-08, 0., 1.e+06);

    fitter->SetParameter(14, "lambda_plus", fPar[14], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(15, "lambda_minus", fPar[15], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(16, "lambda_Sym", fPar[16], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(17, "lambda_Sym1", fPar[17], 1.e-8, 5.e-04, 5.e+03);

    fitter->FixParameter(0);
    fitter->FixParameter(1);
    fitter->FixParameter(2);
    fitter->FixParameter(3);
    fitter->FixParameter(4);
    fitter->FixParameter(5);
    fitter->FixParameter(6);
    fitter->FixParameter(7);
    fitter->FixParameter(8);
    // fitter->FixParameter(9); // nTotlresol

    // fitter->FixParameter(13); // f_Sym1
    // fitter->FixParameter(17); // lambda_Sym1

    Double_t arglist[2] = {10000, 0.1};
    Int_t iret = 0;

    iret = fitter->ExecuteCommand("MIGRAD", arglist, 2);

    fitter->PrintResults(4, 0);

    cout << "Minimization procedure finished\n";
    for (Int_t i = 0; i < 18; i++)
    {
        Double_t paramValue = fitter->GetParameter(i);
        Double_t paramError = fitter->GetParError(i);
        cout << "Parameter " << i << ": Value = " << paramValue << ", Error = " << paramError << endl;
        fValPar[i] = paramValue;
    }
    return iret;
}

// Helper function to create FFT-based convolution
std::vector<double> performFFTConvolution(const std::vector<double> &f1, const std::vector<double> &f2, int nBins)
{
    // FFTs
    TVirtualFFT *fft1 = TVirtualFFT::FFT(1, &nBins, "R2C"); // Forward FFT for f1
    TVirtualFFT *fft2 = TVirtualFFT::FFT(1, &nBins, "R2C"); // Forward FFT for f2

    // Fill FFT with input arrays
    fft1->SetPoints(f1.data());
    fft1->Transform();

    fft2->SetPoints(f2.data());
    fft2->Transform();

    // Multiply in frequency domain
    double *reV = new double[nBins / 2 + 1];
    double *imV = new double[nBins / 2 + 1];
    double re1, im1, re2, im2;
    for (int i = 0; i < nBins / 2 + 1; i++)
    {
        fft1->GetPointComplex(i, re1, im1);
        fft2->GetPointComplex(i, re2, im2);

        // Complex multiplication: (re1 + i*im1) * (re2 + i*im2)
        double reConv = re1 * re2 - im1 * im2; // Real part
        double imConv = re1 * im2 + im1 * re2; // Imaginary part
        TComplex pCompl = TComplex(reConv, imConv);
        fft1->SetPointComplex(i, pCompl);
        reV[i] = reConv;
        imV[i] = imConv;
    }

    // Inverse FFT
    TVirtualFFT *fftInverse = TVirtualFFT::FFT(1, &nBins, "C2R"); // Inverse FFT
    // double *reV=0x0; double *imV=0x0;
    // fft1->GetPointsComplex(reV,imV);
    // fftInverse->SetPointsComplex(fft1->GetPoints());
    fftInverse->SetPointsComplex(reV, imV);
    fftInverse->Transform();

    // Retrieve convolution result
    std::vector<double> result(nBins);
    for (int i = 0; i < nBins; i++)
    {
        result[i] = fftInverse->GetPointReal(i) / nBins; // Normalize
    }

    /*delete fft1;
    delete fft2;
    delete fftInverse;*/

    return result;
}
