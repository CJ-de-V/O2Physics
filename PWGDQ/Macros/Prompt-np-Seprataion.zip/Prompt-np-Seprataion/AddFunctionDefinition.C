//_________________________________________________________________________________________
//            Class to perform unbinned log-likelihood fit
//          Origin: Run-2 AliPhysics codes based on AliDielectronBtoJPSItoEle
// Contact: shreyasi.acharya@cern.ch; fiorella.fionda@cern.ch; Giuseppe.Bruno@cern.ch
//_________________________________________________________________________________________

void MakeReducedNtuple_New(std::vector<TString> &fileNames, TNtuple *ntNew, Double_t ptmin, Double_t ptmax, Double_t mMin1, Double_t mMax1, Int_t fAmbiIn, Int_t fAmbiOut, TH1F *hpromptLxy, Bool_t fMC, Int_t iPlus)
{
    int ncand = 0;
    for (const auto &fileName : fileNames)
    {
        TFile *file = TFile::Open(fileName, "READ");
        if (!file || file->IsZombie())
        {
            std::cerr << "Failed to open file: " << fileName << std::endl;
            continue;
        }
        TIter nextKey(file->GetListOfKeys());
        TKey *key;
        ntNew->SetBasketSize("*", (Long64_t)320000000); // Set larger basket size
        while ((key = (TKey *)nextKey()))
        {
            if (key->IsFolder())
            {
                TDirectory *dir = (TDirectory *)file->Get(key->GetName());
                if (!dir)
                    continue;

                TString nDir = key->GetName();
                if (nDir.Contains("parentFiles"))
                    continue;

                TTree *tree = (TTree *)dir->Get("O2dqpseudoproper");
                if (!tree)
                    continue; // Skip if the tree doesn't exist

                // std::cout << "Processing folder: " << key->GetName() << std::endl;
                Float_t mJPSI = 0;
                Float_t x = 0;
                Float_t xInvMass = 0;
                Float_t xPoleMass = 0;
                Float_t xRecal = 0;
                Float_t transvMom = 0.;
                Bool_t ambiInBunch = 0.;
                Bool_t ambiOutOfBunch = 0.;
                Bool_t correctAssoc = 0.;
                Int_t type = 0;

                Int_t nentries = 0;
                tree->SetBranchAddress("fMassee", &mJPSI);
                tree->SetBranchAddress("fLxyee", &xInvMass);
                tree->SetBranchAddress("fLxyeePoleMass", &xPoleMass);
                tree->SetBranchAddress("fLxyeeRecalculatePV", &xRecal);
                tree->SetBranchAddress("fPtee", &transvMom);
                tree->SetBranchAddress("fAmbiguousInBunchPairs", &ambiInBunch);
                tree->SetBranchAddress("fAmbiguousOutOfBunchPairs", &ambiOutOfBunch);
                if (fMC)
                    tree->SetBranchAddress("fCorrassoc", &correctAssoc);

                nentries = (Int_t)tree->GetEntriesFast();

                for (Int_t i = 0; i < nentries; i += iPlus)
                {
                    tree->GetEntry(i);
                    x = xPoleMass;
                    double xx = x * 10000;

                    if (fAmbiIn < 2)
                    {
                        if (ambiInBunch != fAmbiIn)
                            continue;
                    }
                    if (fAmbiOut < 2)
                    {
                        if (ambiOutOfBunch != fAmbiOut)
                            continue;
                    }
                    if (mJPSI < mMin1 || mJPSI > mMax1)
                        continue;

                    if (transvMom < ptmin || transvMom > ptmax)
                        continue;

                    if (fMC && !correctAssoc)
                        continue;

                    hpromptLxy->Fill(xx);

                    if (fMC)
                        ntNew->Fill(x, mJPSI, transvMom, ambiInBunch, ambiOutOfBunch, correctAssoc);
                    else if (!fMC)
                        ntNew->Fill(x, mJPSI, transvMom, ambiInBunch, ambiOutOfBunch);
                    ncand++;
                }
                delete tree;
                dir->Clear();
            }
        }
        file->Close();
    }
    printf("+++\n+++ Number of total candidates (MakeReducedNtuple_New), within %0.2f < pT <  %0.2f, and mass: [%0.2f - %0.2f] ---> %d candidates \n+++\n", ptmin, ptmax, mMin1, mMax1, ncand);
    // if(ncand == 0){ cout<<" No entries, check"<<endl; getchar();}
    return;
}

void ReadCandidates(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Bool_t *&ambiInBunch, Bool_t *&ambiOutBunch, Bool_t *&CorrectAssoc, Int_t &ncand, Bool_t fMC)
{

    if (!tree)
        return; // Skip if the tree doesn't exist

    Float_t mJPSI = 0;
    Float_t x = 0;
    Float_t type = 0;
    Float_t transvMom = 0.;
    Float_t ambiIn = 0;
    Float_t ambiOut = 0.;
    Float_t corrAssoc = 0.;

    Int_t nentries = 0;
    // tree->Print();
    tree->SetBranchAddress("Xdecaytime", &x);
    tree->SetBranchAddress("Mass", &mJPSI);
    tree->SetBranchAddress("Pt", &transvMom);
    tree->SetBranchAddress("ambiInBunch", &ambiIn);
    tree->SetBranchAddress("ambiOutOfBunch", &ambiOut);
    if (fMC)
        tree->SetBranchAddress("CorrAssoc", &corrAssoc);

    nentries = (Int_t)tree->GetEntriesFast();
    cout << " L170 read entries = " << nentries << endl;
    pseudoproper = new Double_t[nentries];
    invmass = new Double_t[nentries];
    pt = new Double_t[nentries];
    ambiInBunch = new Bool_t[nentries];
    ambiOutBunch = new Bool_t[nentries];
    if (fMC)
        CorrectAssoc = new Bool_t[nentries];

    for (Int_t i = 0; i < nentries; i++)
    {
        tree->GetEntry(i);
        pseudoproper[i] = (Double_t)x * 10000.;
        invmass[i] = (Double_t)mJPSI;
        pt[i] = (Double_t)transvMom;
        ambiInBunch[i] = (Bool_t)ambiIn;
        ambiOutBunch[i] = (Bool_t)ambiOut;
        if (fMC)
            CorrectAssoc[i] = (Bool_t)corrAssoc;
    }
    ncand = nentries;
    cout << " L181 ReadCandidates ncand " << ncand << endl;
    // delete tree;
    // return;
}

void MakeAndReadNonPromptMCTuple(TFile *file, TNtuple *ntNew, Double_t ptmin = 0., Double_t ptmax = 200., TH1F *hnpMCGenLxy = 0x0) // Double_t *&pseudoproperNPMC, Int_t &nPoint,
{
    int ncand = 0;
    TIter nextKey(file->GetListOfKeys());
    TKey *key;
    ntNew->SetBasketSize("*", 320000000); // Set larger basket size
    while ((key = (TKey *)nextKey()))
    {
        if (key->IsFolder())
        {
            TDirectory *dir = (TDirectory *)file->Get(key->GetName());
            if (!dir)
                continue;

            TString nDir = key->GetName();
            if (nDir.Contains("parentFiles"))
                continue;

            TTree *tree = (TTree *)dir->Get("O2mcpseudoproper");
            if (!tree)
                continue; // Skip if the tree doesn't exist

            std::cout << "Processing folder: " << key->GetName() << std::endl;
            Float_t transvMom = 0;
            Float_t x = 0;
            Float_t rap = 0;
            Int_t nentries = 0;
            tree->SetBranchAddress("fMCPt", &transvMom);
            tree->SetBranchAddress("fMCY", &rap);
            tree->SetBranchAddress("fMCTauxy", &x);

            nentries = (Int_t)tree->GetEntriesFast();

            for (Int_t i = 0; i < nentries; i++)
            {
                tree->GetEntry(i);
                Double_t xx = x;
                // xx = ncand;

                if (transvMom < ptmin || transvMom > ptmax)
                    continue;

                if (rap < -0.9 || rap > 0.9)
                    continue;

                hnpMCGenLxy->Fill(xx);

                ntNew->Fill(xx);
                ncand++;
            }
        }
    }
    printf("+++\n+++ Non prompt MC candidates, within %0.2f < pT <  %0.2f ---> %d candidates \n+++\n", ptmin, ptmax, ncand);

    return;
}

void ReadNPMCCandidates(TNtuple *tree, Double_t *&pseudoproperNPMC, Int_t &ncandMC)
{
    if (!tree)
        return; // Skip if the tree doesn't exist

    Float_t xNPMCGen = 0;
    Int_t nentries = 0;

    tree->SetBranchAddress("Xdecaytime", &xNPMCGen);
    nentries = (Int_t)tree->GetEntriesFast();
    pseudoproperNPMC = new Double_t[nentries];

    ncandMC = 0;
    for (Int_t i = 0; i < nentries; i++)
    {
        tree->GetEntry(i);
        pseudoproperNPMC[ncandMC] = (Double_t)xNPMCGen;
        ncandMC++;
    }
    return;
}
void Hist1DStyle(TH1F *h, int kMarker, float kMarkSize, int kColor, TString xTitle, TString yTitle)
{
    h->SetMarkerStyle(kMarker);
    h->SetMarkerSize(kMarkSize);
    h->SetMarkerColor(kColor);
    h->SetLineColor(kColor);

    h->GetXaxis()->SetTitle(xTitle);
    h->GetYaxis()->SetTitle(yTitle);

    h->GetXaxis()->SetTitleOffset(1.1);
    h->GetYaxis()->SetTitleOffset(1.0);
    h->GetXaxis()->SetTitleSize(0.045);
    h->GetYaxis()->SetTitleSize(0.045);

    h->GetXaxis()->SetLabelSize(0.045);
    h->GetYaxis()->SetLabelSize(0.045);
    h->GetYaxis()->SetLabelOffset(0.01);
    h->GetYaxis()->SetLabelOffset(0.01);
}

Double_t ResolutionFunction(Double_t px, Double_t *par)
{
    Double_t norm1 = par[0];
    Double_t mean1 = par[1];
    Double_t sigma1 = par[2];

    Double_t norm2 = par[3];
    Double_t mean2 = par[4];
    Double_t sigma2 = par[5];

    Double_t alfa = par[6];
    Double_t lambda = par[7];
    Double_t norm3 = par[8];

    Double_t fitval = 0.;

    Double_t x = px;

    if (TMath::Abs(x) <= alfa)
        fitval = (lambda - 1) / (2 * alfa * lambda);
    else
        fitval = ((lambda - 1) / (2 * alfa * lambda)) * TMath::Power(alfa, lambda) * (TMath::Power(TMath::Abs(x), -1 * lambda));

    double G1 = norm1 * TMath::Gaus(x, mean1, sigma1, kTRUE);
    double G2 = norm2 * TMath::Gaus(x, mean2, sigma2, kTRUE);
    double Pow1 = norm3 * fitval;
    double ret = (G1 + G2 + Pow1) / (norm1 + norm2 + norm3);
    return ret;
}

Double_t FunBkgPos(Double_t x, Double_t *fPar) // exponential with positive slopes for the background part (x)
{
    Double_t np, sc, sigma3;
    sc = 10.;
    np = 1000.0;
    sigma3 = 1000.;

    Double_t xprime;
    Double_t sum = 0.0;
    Double_t xlow, xupp;
    Double_t step;
    Double_t i;
    xlow = x - sc * sigma3;
    xupp = x + sc * sigma3;
    step = (xupp - xlow) / np;

    for (i = 1.0; i <= np / 2; i++)
    {
        xprime = xlow + (i - .5) * step;

        if (xprime > 0)
        {
            sum += fPar[14] * TMath::Exp(-1 * xprime * fPar[14]) * (ResolutionFunction(xprime - x, fPar));
        }

        xprime = xupp - (i - .5) * step;
        if (xprime > 0)
        {
            sum += fPar[14] * TMath::Exp(-1 * xprime * fPar[14]) * (ResolutionFunction(xprime - x, fPar));
        }
    }
    return step * sum;
}

Double_t FunBkgNeg(Double_t x, Double_t *fPar) // exponential with negative slopes for the background part (x)
{
    Double_t np, sc, sigma3;
    sc = 10.;
    np = 1000.0;
    sigma3 = 1000.;

    Double_t xprime;
    Double_t sum = 0.0;
    Double_t xlow, xupp;
    Double_t step;
    Double_t i;
    xlow = x - sc * sigma3;
    xupp = x + sc * sigma3;
    step = (xupp - xlow) / np;

    for (i = 1.0; i <= np / 2; i++)
    {
        xprime = xlow + (i - .5) * step;
        if (xprime < 0)
            sum += fPar[15] * TMath::Exp(xprime * fPar[15]) * (ResolutionFunction(xprime - x, fPar));

        xprime = xupp - (i - .5) * step;
        if (xprime < 0)
            sum += fPar[15] * TMath::Exp(xprime * fPar[15]) * (ResolutionFunction(xprime - x, fPar));
    }

    return step * sum;
}

Double_t FunBkgSym(Double_t x, Double_t *fPar) // exponential with both positive and negative slopes for the background part (x)
{
    Double_t np, sc, sigma3;
    sc = 10.;
    np = 1000.0;
    sigma3 = 1000.;

    Double_t xprime;
    Double_t sum1 = 0.0;
    Double_t sum2 = 0.0;
    Double_t xlow, xupp;
    Double_t step;
    Double_t i;
    xlow = x - sc * sigma3;
    xupp = x + sc * sigma3;
    step = (xupp - xlow) / np;

    for (i = 1.0; i <= np / 2; i++)
    {
        xprime = xlow + (i - .5) * step;
        if (xprime > 0)
            sum1 += 0.5 * fPar[16] * TMath::Exp(-1 * xprime * fPar[16]) * (ResolutionFunction(xprime - x, fPar));
        else if (xprime < 0)
            sum2 += 0.5 * fPar[16] * TMath::Exp(xprime * fPar[16]) * (ResolutionFunction(xprime - x, fPar));

        xprime = xupp - (i - .5) * step;
        if (xprime > 0)
            sum1 += 0.5 * fPar[16] * TMath::Exp(-1 * xprime * fPar[16]) * (ResolutionFunction(xprime - x, fPar));
        else if (xprime < 0)
            sum2 += 0.5 * fPar[16] * TMath::Exp(xprime * fPar[16]) * (ResolutionFunction(xprime - x, fPar));
    }

    return step * (sum1 + sum2);
}

Double_t FunBkgSym1(Double_t x, Double_t *fPar) // exponential with both positive and negative slopes for the background part (x)
{
    Double_t np, sc, sigma3;
    sc = 10.;
    np = 1000.0;
    sigma3 = 1000.;

    Double_t xprime;
    Double_t sum1 = 0.0;
    Double_t sum2 = 0.0;
    Double_t xlow, xupp;
    Double_t step;
    Double_t i;
    xlow = x - sc * sigma3;
    xupp = x + sc * sigma3;
    step = (xupp - xlow) / np;

    for (i = 1.0; i <= np / 2; i++)
    {
        xprime = xlow + (i - .5) * step;
        if (xprime > 0)
            sum1 += 0.5 * fPar[17] * TMath::Exp(-1 * xprime * fPar[17]) * (ResolutionFunction(xprime - x, fPar));
        else if (xprime < 0)
            sum2 += 0.5 * fPar[17] * TMath::Exp(xprime * fPar[17]) * (ResolutionFunction(xprime - x, fPar));

        xprime = xupp - (i - .5) * step;
        if (xprime > 0)
            sum1 += 0.5 * fPar[17] * TMath::Exp(-1 * xprime * fPar[17]) * (ResolutionFunction(xprime - x, fPar));
        else if (xprime < 0)
            sum2 += 0.5 * fPar[17] * TMath::Exp(xprime * fPar[17]) * (ResolutionFunction(xprime - x, fPar));
    }

    return step * (sum1 + sum2);
}

Double_t EvaluateCDFDecayTimeBkgDistr(Double_t x, Double_t *fPar)
{
    Double_t ret = 0.;

    Double_t cResol = fPar[9] * ResolutionFunction(x, fPar); // Resolution component,
    // Double_t cResol = (1 -fPar[13] + fPar[9] + fPar[10] + fPar[11] + fPar[12]) * ResolutionFunction(x, fPar); // Resolution component,
    Double_t cBkgPos = fPar[10] * FunBkgPos(x, fPar);   // f = 10, lambda = 14
    Double_t cBkgNeg = fPar[11] * FunBkgNeg(x, fPar);   //  f = 11, lambda = 15
    Double_t cBkgSym = fPar[12] * FunBkgSym(x, fPar);   //  f = 12, lambda = 16
    Double_t cBkgSym1 = fPar[13] * FunBkgSym1(x, fPar); // f = 13, lambda = 17

    Double_t normFact = fPar[9] + fPar[10] + fPar[11] + fPar[12] + fPar[13];

    ret = (cResol + cBkgPos + cBkgNeg + cBkgSym + cBkgSym1) / (1. * normFact);

    return ret;
}
