
//_________________________________________________________________________________________
//            Class to perform unbinned log-likelihood fit
//          Origin: Run-2 AliPhysics codes based on AliDielectronBtoJPSItoEle
// Contact: shreyasi.acharya@cern.ch; fiorella.fionda@cern.ch; Giuseppe.Bruno@cern.ch
//_________________________________________________________________________________________

#include "TROOT.h"
#include "TSystem.h"
#include "TFile.h"
#include "TNtuple.h"
#include "TCanvas.h"
#include "TF1.h"
#include "TFitResult.h"
#include "TH1F.h"
#include "TLatex.h"
#include "TDatabasePDG.h"
#include "TString.h"
#include "TMath.h"
#include "TStopwatch.h"
#include "TMinuit.h"
#include "TKey.h"
#include "TFitter.h"
#include "TStyle.h"
#include "TFFTReal.h"
#include "TMath.h"
#include "TLegend.h"
#include "TComplex.h"
#include "Math/MinimizerOptions.h"
#include "TVectorT.h"
#include "Math/PdfFuncMathCore.h"
#include "AddFunctionDefinition.C"

void SetStyle();
void Hist1DStyle(TH1F *h, int kMarker, float kMarkSize, int kColor, TString xTitle = "", TString yTitle = "");
void MakeReducedNtuple_New(std::vector<TString> &fileNames, TNtuple *ntNew, Double_t ptmin = 0., Double_t ptmax = 200., Double_t mMin1 = 2, Double_t mMax1 = 6., Int_t fAmbiIn = 9, Int_t fAmbiOut = 9, TH1F *h = 0x0, Bool_t isMC = false, Int_t iPlus = 1);
void ReadCandidates(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Bool_t *&ambiIn, Bool_t *&ambiOut, Bool_t *&CorrectAssoc, Int_t &ncand, Bool_t isMC = false);
void ReadCandidates_old(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Int_t &ncand);

Double_t ResolutionFunction(double x, double *);
Double_t FunBkgPos(Double_t x, Double_t *);
Double_t FunBkgNeg(Double_t x, Double_t *);
Double_t FunBkgSym(Double_t x, Double_t *);
Double_t FunBkgSym1(Double_t x, Double_t *);

void ComputeMassIntegral(Double_t *fPar);

Double_t EvaluateCDFfuncBkgPart(Double_t x, Double_t m, Double_t *fPar);
Double_t EvaluateCDFInvMassBkgDistr(Double_t m, Double_t *fPar);
Double_t EvaluateCDFDecayTimeBkgDistr(Double_t x, Double_t *);

Double_t EvaluateCDFfuncSignalPart(Double_t x, Double_t m, Double_t *fPar);
Double_t EvaluateCDFDecayTimeSigDistr(Double_t x, Double_t *fPar);
Double_t EvaluateCDFInvMassSigDistr(Double_t m, Double_t *fPar);

Double_t EvaluateCDFDecayTimeTotalDistr(Double_t x, Double_t *fPar);
Double_t EvaluateCDFInvMassTotalDistr(Double_t x, Double_t *fPar);

Double_t EvaluateCDFfuncNorm(Double_t x, Double_t m, Double_t *fPar);
Double_t EvaluateLikelihood(const Double_t *pseudoproperdecaytime, Double_t *invMass, Int_t ncand, Double_t *par);
void CdfFCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag);
void CDFFunction(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag);
Int_t DoMinimization(Double_t *);

Double_t CallCDFBkgDecayTimeTotal(Double_t *x, Double_t *par);
Double_t CallCDFInvMassTotal(Double_t *m, Double_t *par);
Double_t CallPromptMCDecayTimePart(Double_t *x, Double_t *par);
Double_t CallNonPromptMCDecayTimePart(Double_t *x, Double_t *par);
Double_t CallBkgDecayTimePart(Double_t *x, Double_t *par);
Double_t CallSigInvMassPart(Double_t *x, Double_t *par);
Double_t CallBkgInvMassPart(Double_t *x, Double_t *par);
//=================================================
Double_t RecoNonPromptJpsiTemplate(Double_t *x, Double_t *par);
Double_t ConvoluteGeneratedNPMCTime(Double_t x, Double_t *par);
Double_t ConvoluteGeneratedNPMCTimeNorm(Double_t *x, Double_t *fPar);
Double_t GetGenNPMCx(Double_t x);
Double_t CallConvoluteGenxMCNPFunc(Double_t *x, Double_t *par);

Double_t *fX = 0x0;
Double_t *fM = 0x0;
Int_t nCand;

Double_t *fXMCGen = 0x0;
Int_t nCandMC;
TH1F *hxGenNpMc;
Bool_t useRecoTemplateFitted = kFALSE;

Double_t fintmMassBkg;
Double_t fintmMassSig;

Double_t fMassWndHigh;
Double_t fMassWndLow;

Double_t fValPar[32];
Double_t fValParErr[32];
Bool_t kExpo = kTRUE;

void Fit_Convl_2D(int kk = 10, Bool_t kExpInput = kTRUE, Double_t massBkgMin1 = 3.20, Double_t massBkgMax1 = 3.40, Double_t massBkgMin2 = 0, Double_t massBkgMax2 = 0, Double_t massSignalMin = 2.4, Double_t massSignalMax = 3.2, Int_t iSkip = 1)
{
    Double_t ptBins[] = {0., 0.5, 1., 1.5, 2., 2.5, 3., 3.5, 4., 4.5, 5, 6, 7., 8, 10, 12, 15, 20};
    Double_t ptMin = ptBins[kk];
    Double_t ptMax = ptBins[kk + 1];
    Double_t fSig = 0.;

    int rebin = 2;
    kExpo = kExpInput;
    //-----------------NP-MC to be USED------------
    Double_t massMCnpMin = 1.0;
    Double_t massMCnpMax = 4.0;

    float rValX1 = -2000;
    float rValX2 = 4000;
    //========================================================
    //=============== READ INPUT DATA and MC =================
    //========================================================
    TString sFolOpen;
    TString inputData;
    TString sFolder;
    TString subFolderData;
    TString subFoldernpMC;

  
    sFolOpen = "v7_4sigma_data_2024";

    inputData = Form("InputFiles/");
    // subFoldernpMC = Form("%s/250322_4sigma/", sFolder.Data());

    Double_t rFac[] = {0.99216, 0.98608, 0.974169, 0.931595, 0.926564, 0.892059, 0.887907, 0.860104, 0.848122, 0.850648, 0.845165, 0.845165, 0.845165, 0.845165, 0.845165, 0.845165, 0.845165};

    //----------------- DATA --------------
    std::vector<TString> fileNamesData;
    TString sFile1 = Form("%s/dileptonAOD_Data_24pass1_4sigma.root", inputData.Data());
    fileNamesData.push_back(sFile1);

    //--------------- NP-MC ---------------
    std::vector<TString> fileNamesNP;
    TString sFolderMC;

    sFolderMC = Form("InputFiles/");
    TString sFileNP1 = Form("%s/dileptonAOD_npMC_1.root", sFolderMC.Data());
    fileNamesNP.push_back(sFileNP1);
   

    //--------------- BKG DATA ---------------

    TFile *fBkg = TFile::Open(Form("OutputRoot/data/%s/OutputBkgFit/mass_%0.02f_%0.02f_%0.02f_%0.02f/bkgfunc_pt_%0.02f_%0.02f.root", sFolOpen.Data(), massBkgMin2, massBkgMax2, massBkgMin1, massBkgMax1, ptMin, ptMax));

    //--------------- INV MASS DATA ---------------
    TFile *fInvMass = TFile::Open(Form("OutputRoot/data/%s/invMassFit_%d_BkgFunc/data_invMassFit_pt_%0.02f_%0.02f.root", sFolOpen.Data(), !(kExpo), ptMin, ptMax));

    //========================================================
    //================== READ FIT VALUES =====================
    //========================================================
    TVectorD *paramsBkg = (TVectorD *)fBkg->Get("paramsBkg");
    if (paramsBkg)
        cout << " valid Bkg params !!!!!!!" << " Rows = " << paramsBkg->GetNrows() << " \n\n";
    for (int ii = 0; ii < 18; ii++)
        cout << (*paramsBkg)(ii) << ", ";
    cout << endl;

    TVectorD *paramsInv = (TVectorD *)fInvMass->Get("myParams_Data;1");
    if (paramsInv)
        cout << " valid InvMass params !!!!!!!" << " Rows = " << paramsInv->GetNrows() << " \n\n";
    for (int ii = 0; ii < paramsInv->GetNrows(); ii++)
        cout << (*paramsInv)(ii) << ", ";
    cout << endl;

    TVectorD *paramsfSig = (TVectorD *)fInvMass->Get("myparam_SignalFrac;1");
    if (paramsfSig)
        cout << " valid fSig params !!!!!!!" << " Rows = " << paramsfSig->GetNrows() << " \n\n";
    for (int ii = 0; ii < paramsfSig->GetNrows(); ii++)
        cout << (*paramsfSig)(ii) << ", ";
    cout << endl;

    //========================================================
    if (massSignalMin == 2.7 && massSignalMax == 3.2)
        fSig = (*paramsfSig)(0);
    if (massSignalMin == 2.4 && massSignalMax == 3.2)
        fSig = (*paramsfSig)(1);

    Double_t fParamAll[] = {(*paramsBkg)(0), (*paramsBkg)(1), (*paramsBkg)(2), (*paramsBkg)(3), (*paramsBkg)(4), (*paramsBkg)(5), (*paramsBkg)(6), (*paramsBkg)(7), (*paramsBkg)(8), (*paramsBkg)(9), (*paramsBkg)(10), (*paramsBkg)(11), (*paramsBkg)(12), (*paramsBkg)(13), (*paramsBkg)(14), (*paramsBkg)(15), (*paramsBkg)(16), (*paramsBkg)(17), 1., fSig, 0.70, (*paramsInv)(0), (*paramsInv)(1), (*paramsInv)(2), (*paramsInv)(3), (*paramsInv)(4), (*paramsInv)(5), (*paramsInv)(6), (*paramsInv)(7), (*paramsInv)(8), (*paramsInv)(9), (*paramsInv)(10)}; // 0.68

    //========================================================
    //================== DEFINE HISTOGRAM ====================
    //========================================================

    fMassWndHigh = massSignalMax;
    fMassWndLow = massSignalMin;

    float rangeResolFit = 8000;
    double factor = 0.1;

    float rangeMassHistoLow = 2.21;
    float rangeMassHistoHigh = 3.41;
    double nbinsMass = 120;
    double binWidth = (rangeMassHistoHigh - rangeMassHistoLow) / nbinsMass;

    //-------------------------------------
    //-------------DATA IN SIGNAL----------
    //-------------------------------------

    Double_t *pseudoproperTime = 0x0;
    Double_t *mass = 0x0;
    Double_t *pt = 0x0;
    Bool_t *CorrAssocRecoMCnp = 0x0;
    Bool_t *ambIn = 0x0;
    Bool_t *ambOut = 0x0;
    Bool_t *corrA = 0x0;
    TNtuple *ntJPsi_DataSig = new TNtuple("ntJPsi_DataSig", "ntJPsi_DataSig", "Xdecaytime:Mass:Pt:ambiInBunch:ambiOutOfBunch");

    TH1F *hData_Time = new TH1F("hData_Time", Form(""), rangeResolFit * factor, -1. * rangeResolFit, rangeResolFit);
    hData_Time->Sumw2();
    TH1F *hData_InvMass = new TH1F("hData_InvMass", Form(""), nbinsMass, rangeMassHistoLow, rangeMassHistoHigh);
    hData_InvMass->Sumw2();

    MakeReducedNtuple_New(fileNamesData, ntJPsi_DataSig, ptMin, ptMax, massSignalMin, massSignalMax, 9, 9, hData_Time, false, iSkip);
    ReadCandidates(ntJPsi_DataSig, pseudoproperTime, mass, pt, ambIn, ambOut, corrA, nCand, false); // read N-Tuples from Data-Bkg

    fX = new Double_t[nCand];
    fX = pseudoproperTime;

    fM = new Double_t[nCand];
    fM = mass;

    for (Int_t i = 0; i < nCand; i++)
        hData_InvMass->Fill(fM[i]);

    //----------------------------------------
    //-------------NON PROMPT MC GEN----------
    //----------------------------------------

    Double_t *pseudoproperTimeRecoMCnp = 0x0;
    Double_t *massRecoMCnp = 0x0;
    Double_t *ptRecoMCnp = 0x0;
    Int_t *typeRecoMCnp = 0;
    int nCandMCGen;

    TNtuple *ntJPsi_MCnp_Reco = new TNtuple("ntJPsi_MCnp_Reco", "ntJPsi_MCnp_Reco", "Xdecaytime:Mass:Pt:ambiInBunch:ambiOutOfBunch");
    TH1F *htime_MCnp_reco = new TH1F("Time_MCNP_Reco", Form(""), rangeResolFit * factor, -1 * rangeResolFit, rangeResolFit);
    htime_MCnp_reco->Sumw2();

    MakeReducedNtuple_New(fileNamesNP, ntJPsi_MCnp_Reco, ptMin, ptMax, massMCnpMin, massMCnpMax, 9, 9, htime_MCnp_reco, false, 1);
    ReadCandidates_old(ntJPsi_MCnp_Reco, pseudoproperTimeRecoMCnp, massRecoMCnp, ptRecoMCnp, nCandMCGen); // read N-Tuples

    hxGenNpMc = (TH1F *)htime_MCnp_reco->Clone("hnpMC_Reco_time");

    TCanvas *c1np = new TCanvas();
    if (useRecoTemplateFitted)
    {
        // fit  NP
        TF1 *convNP = new TF1("RecoNonPromptJpsiTemplate", RecoNonPromptJpsiTemplate, -8000., 8000., 6);
        convNP->SetNpx(5000.);
        convNP->SetParameters(0.026078, 60., 52., 0.003264, 0.00216182, 500.);
        if (kk == 1)
            convNP->SetParameters(6.04704, 74.7312, 110.106, 4.23814, 0.00304923, 51352);
        if (kk == 2)
            convNP->SetParameters(7.67696, 67.0036, 69.6281, 6.52515, 0.00388575, 51316.7);
        if (kk == 3)
            convNP->SetParameters(9.98918, 69.2768, 61.2943, 6.02018, 0.00336256, 39107.9);
        if (kk == 4)
            convNP->SetParameters(9.87783, 64.613, 49.9962, 6.54787, 0.00297804, 31122.4);
        if (kk == 5)
            convNP->SetParameters(0.0702768, 51.217, 45.0675, 0.0528722, 0.00312401, 33524.7);
        if (kk == 6)
            convNP->SetParameters(9.96531, 41.0797, 39.1615, 7.79496, 0.00267549, 17325.6);
        convNP->SetParLimits(0, 0., 1.e+01);
        convNP->SetParLimits(1, -1.e+02, 1.e+04);
        convNP->SetParLimits(2, 0., 1.e+04);
        convNP->SetParLimits(3, 0.01, 1.e+02);
        convNP->SetParLimits(4, 0., 1.e+04);

        c1np->SetRightMargin(0.01738123);
        c1np->SetTopMargin(0.02608695);
        c1np->SetLogy();
        htime_MCnp_reco->GetXaxis()->SetRangeUser(-1500, 3500);

        htime_MCnp_reco->Fit(convNP);
        TFitResultPtr rFitRes_np = htime_MCnp_reco->Fit(convNP->GetName(), "S0", "", -8000., 8000.);
        for (int ij = 0; ij < 6; ij++)
            convNP->SetParameter(ij, rFitRes_np->Parameter(ij));

        htime_MCnp_reco->DrawCopy();
        convNP->Draw("same");

        // fill hist using function
        hxGenNpMc->Reset();
        for (int i = 1; i < hxGenNpMc->GetNbinsX() + 1; i++)
        {
            hxGenNpMc->SetBinContent(i, convNP->Eval(hxGenNpMc->GetBinCenter(i)));
        }
    }

    Double_t integralMCnp = 0;
    for (int i = 1; i < hxGenNpMc->GetNbinsX() + 1; i++)
        integralMCnp += (hxGenNpMc->GetBinContent(i) * hxGenNpMc->GetBinWidth(i));
    hxGenNpMc->Scale(1. / integralMCnp);

    cout << " integralMCnp = " << integralMCnp << " hxGenNpMc->GetNbinsX()  = " << hxGenNpMc->GetNbinsX() << endl;

    //========================================================
    //======================= MINIMIZE =======================
    //========================================================

    Int_t numElements = sizeof(fParamAll) / sizeof(Double_t);
    cout << "numElements for All = " << numElements << endl;
    for (int ii = 0; ii < numElements; ii++)
        cout << fParamAll[ii] << ", \n";

    ComputeMassIntegral(fParamAll);
    DoMinimization(fParamAll);

    //========================================================
    //========================= DRAW =========================
    //========================================================
    TCanvas *c4Mass5Time = new TCanvas("c4Mass5Time", "", 242, 73, 1226, 599);
    c4Mass5Time->Divide(2, 1);
    c4Mass5Time->cd(1);
    gPad->SetRightMargin(0.01253133);
    gPad->SetTopMargin(0.01391304);
    gStyle->SetOptStat(0);
    /*
    TCanvas *c4Mass = new TCanvas("c4Mass", "Mass ", 800, 600);
    c4Mass->SetRightMargin(0.01253133);
    c4Mass->SetTopMargin(0.01391304);
    c4Mass->cd();
    */
    hData_InvMass->GetXaxis()->SetTitle("#it{m}_{ee} (GeV/#it{c}^{2})");
    hData_InvMass->GetYaxis()->SetTitle("Entries");
    hData_InvMass->SetMarkerColor(kBlack);
    hData_InvMass->SetLineColor(kBlack);
    hData_InvMass->Draw();

    TF1 *fpsMassData = new TF1("fpsMassData", CallCDFInvMassTotal, massSignalMin, massSignalMax, numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        printf("L305 val Par %d -> %f \n", ii, fValPar[ii]);
        fpsMassData->FixParameter(ii, fValPar[ii]);
    }
    fpsMassData->SetParameter(numElements, hData_InvMass->GetEntries() * hData_InvMass->GetBinWidth(1));

    TFitResultPtr rpsMassData = hData_InvMass->Fit("fpsMassData", "S0"); //
    fpsMassData->SetLineColor(kRed);
    fpsMassData->SetLineWidth(2);
    fpsMassData->SetNpx(500);
    fpsMassData->Draw("same l");

    TVectorD *chi2ndfVec_Mass = new TVectorD(3);
    (*chi2ndfVec_Mass)[0] = rpsMassData->Chi2();
    (*chi2ndfVec_Mass)[1] = rpsMassData->Ndf();
    (*chi2ndfVec_Mass)[2] = (rpsMassData->Chi2() / rpsMassData->Ndf());
    cout << " chi2/ndf = " << (*chi2ndfVec_Mass)[0] << "/" << (*chi2ndfVec_Mass)[1] << " = " << (*chi2ndfVec_Mass)[2] << endl;

    TF1 *fpsMassDataBkg = new TF1("fpsMassDataBkg", CallBkgInvMassPart, massSignalMin, massSignalMax, numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
        fpsMassDataBkg->SetParameter(ii, fValPar[ii]);
    fpsMassDataBkg->SetLineColor(kOrange + 1);
    fpsMassDataBkg->SetLineWidth(2);
    fpsMassDataBkg->SetParameter(numElements, rpsMassData->Parameter(32) * (1. - rpsMassData->Parameter(19))); //
    printf("normalisation %f - fSig %f \n", rpsMassData->Parameter(32), rpsMassData->Parameter(19));
    fpsMassDataBkg->Draw("same l");

    TF1 *fpsMassDataSig = new TF1("fpsMassDataSig", CallSigInvMassPart, massSignalMin, massSignalMax, numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
        fpsMassDataSig->SetParameter(ii, fValPar[ii]);
    fpsMassDataSig->SetLineColor(kGreen + 2);
    fpsMassDataSig->SetLineWidth(2);
    fpsMassDataSig->SetParameter(numElements, rpsMassData->Parameter(32) * rpsMassData->Parameter(19)); // CHANGED (sgn should be scaled by fsig)
    fpsMassDataSig->Draw("same l");

    TLegend *legMass = new TLegend(0.1391612, 0.7897675, 0.3400054, 0.9728721);
    legMass->SetTextSize(0.035);
    legMass->SetBorderSize(0);
    legMass->SetFillStyle(0);
    legMass->AddEntry("NULL", Form("S[%1.2f - %1.2f (GeV/#it{c}^{2})] = %4.1f #pm %4.1f ", massSignalMin, massSignalMax, fpsMassData->Integral(massSignalMin, massSignalMax) / hData_InvMass->GetBinWidth(1), TMath::Sqrt(fpsMassData->Integral(massSignalMin, massSignalMax) / hData_InvMass->GetBinWidth(1))), "h");
    legMass->AddEntry("NULL", Form("#it{f}_{sig} = %4.3f #pm %4.3f", fValPar[19], fValParErr[19]), "h");
    legMass->AddEntry("NULL", Form("#chi^{2}/dof = %4.3f ", (rpsMassData->Chi2() / rpsMassData->Ndf())), "h");
    legMass->Draw();

    cout << " ============================ " << endl;
    cout << " ==========TIME============== " << endl;
    cout << " ============================ " << endl;

    c4Mass5Time->cd(2);
    gPad->SetRightMargin(0.01253133);
    gPad->SetTopMargin(0.01391304);
    gPad->SetLogy();
    gStyle->SetOptStat(0);

    hData_Time->Rebin(rebin);
    hData_Time->Scale(1. / rebin);
    hData_Time->GetXaxis()->SetRangeUser(rValX1, rValX2);
    hData_Time->GetXaxis()->SetTitle("Pseudoproper decay time (#mum)");
    hData_Time->GetYaxis()->SetTitle("Entries");
    hData_Time->SetMarkerColor(kBlack);
    hData_Time->SetLineColor(kBlack);
    hData_Time->Draw();

    TF1 *fTotalFitTimeData = new TF1("fTotalFitTimeData", CallCDFBkgDecayTimeTotal, -6000, 6000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        printf("val Par %d -> %f \n", ii, fValPar[ii]);
        fTotalFitTimeData->FixParameter(ii, fValPar[ii]);
    }
    fTotalFitTimeData->SetParameter(numElements, hData_Time->GetEntries() * hData_Time->GetBinWidth(1));
    TFitResultPtr rpsTimeData = hData_Time->Fit("fTotalFitTimeData", "S0");
    fTotalFitTimeData->SetLineColor(kRed);
    fTotalFitTimeData->SetLineWidth(2);
    fTotalFitTimeData->SetNpx(500);
    fTotalFitTimeData->Draw("same l");

    TVectorD *chi2ndfVec_Time = new TVectorD(3);
    (*chi2ndfVec_Time)[0] = rpsTimeData->Chi2();
    (*chi2ndfVec_Time)[1] = rpsTimeData->Ndf();
    (*chi2ndfVec_Time)[2] = (rpsTimeData->Chi2() / rpsTimeData->Ndf());
    cout << " chi2/ndf = " << (*chi2ndfVec_Time)[0] << "/" << (*chi2ndfVec_Time)[1] << " = " << (*chi2ndfVec_Time)[2] << endl;

    Double_t fbcorr = 1. / (1 + ((1 - fValPar[20]) / (fValPar[20])) * (rFac[kk]));
    Double_t fbcorr_err = 1. / (1 + ((1 - fValParErr[20]) / (fValParErr[20])) * (rFac[kk]));

    TLegend *legPs = new TLegend(0.5425517, 0.7524355, 0.743396, 0.9710944);
    legPs->SetTextSize(0.035);
    legPs->SetBorderSize(0);
    legPs->SetFillStyle(0);
    legPs->AddEntry("NULL", Form(" %0.2f < #it{p}_{T}^{ee} < %0.2f", ptMin, ptMax), "h");
    legPs->AddEntry("NULL", Form("#it{f}_{B}^{raw} = %4.3f #pm %4.3f", fValPar[20], fValParErr[20]), "h");
    legPs->AddEntry("NULL", Form("#it{f}_{B}^{corr} = %4.3f #pm %4.3f", fbcorr, fbcorr_err), "h");
    legPs->AddEntry("NULL", Form("#chi^{2}/dof = %4.3f ", (rpsTimeData->Chi2() / (Double_t)rpsTimeData->Ndf())), "h");
    legPs->Draw();

    TF1 *fPromptMCDecayTimePart = new TF1("fPromptMCDecayTimePart", CallPromptMCDecayTimePart, -6000, 6000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fPromptMCDecayTimePart->SetParameter(ii, fValPar[ii]);
    }
    fPromptMCDecayTimePart->SetParameter(numElements, rpsTimeData->Parameter(32));
    fPromptMCDecayTimePart->SetLineColor(kTeal + 2);
    fPromptMCDecayTimePart->SetLineWidth(2);
    fPromptMCDecayTimePart->SetNpx(500);
    fPromptMCDecayTimePart->Draw("same l");
    printf("integrale prompt -> %f \n", fPromptMCDecayTimePart->Integral(-8000., 8000.) / (rpsTimeData->Parameter(32) * rpsTimeData->Parameter(19) * (1. - rpsTimeData->Parameter(20))));

    TF1 *fNonPromptMCDecayTimePart = new TF1("fNonPromptMCDecayTimePart", CallNonPromptMCDecayTimePart, -8000, 8000., numElements + 1); // CHANGED
    for (int ii = 0; ii < numElements; ii++)
    {
        fNonPromptMCDecayTimePart->SetParameter(ii, fValPar[ii]);
    }
    fNonPromptMCDecayTimePart->SetParameter(numElements, rpsTimeData->Parameter(32));
    fNonPromptMCDecayTimePart->SetLineColor(kAzure - 3);
    fNonPromptMCDecayTimePart->SetLineWidth(2);
    fNonPromptMCDecayTimePart->SetNpx(500);
    fNonPromptMCDecayTimePart->Draw("same l");

    printf("integrale non-prompt -> %f \n", fNonPromptMCDecayTimePart->Integral(-8000., 8000.) / (rpsTimeData->Parameter(32) * rpsTimeData->Parameter(19) * rpsTimeData->Parameter(20)));

    TF1 *fDataBkgDecayTimePart = new TF1("fDataBkgDecayTimePart", CallBkgDecayTimePart, -8000, 8000., numElements + 1);
    for (int ii = 0; ii < numElements; ii++)
    {
        fDataBkgDecayTimePart->SetParameter(ii, fValPar[ii]);
    }
    fDataBkgDecayTimePart->SetParameter(numElements, rpsTimeData->Parameter(32));
    fDataBkgDecayTimePart->SetLineColor(kOrange + 2);
    fDataBkgDecayTimePart->SetLineWidth(2);
    fDataBkgDecayTimePart->SetNpx(500);
    fDataBkgDecayTimePart->Draw("same l");

    TLegend *bTime = new TLegend(0.7263753, 0.5533314, 0.9272195, 0.736436);
    bTime->SetTextSize(0.04);
    bTime->SetBorderSize(0);
    bTime->SetFillStyle(0);
    bTime->AddEntry(fDataBkgDecayTimePart, Form("Bkg (data) "), "lp");
    bTime->AddEntry(fNonPromptMCDecayTimePart, Form("np-MC"), "lp");
    bTime->AddEntry(fPromptMCDecayTimePart, Form("p-MC"), "lp");
    bTime->AddEntry(fTotalFitTimeData, Form("Total fit"), "lp");
    bTime->Draw();
    //========================================================
    //==================== PARAMETERS ========================
    //========================================================

    TVectorD *fSig_fB = new TVectorD(4);
    (*fSig_fB)[0] = fValPar[19];
    (*fSig_fB)[1] = fValParErr[19];
    (*fSig_fB)[2] = fValPar[20];
    (*fSig_fB)[3] = fValParErr[20];

    TVectorD *paramsTotalSave = new TVectorD(numElements + 1);
    for (int ii = 0; ii < numElements + 1; ii++)
    {
        (*paramsTotalSave)[ii] = fTotalFitTimeData->GetParameter(ii);
        cout << (*paramsTotalSave)[ii] << ", ";
    }
    cout << endl;

    //========================================================
    //==================== SAVE ==============================
    //========================================================

    TString sFolSave2 = Form("OutputRoot/data/%s/FinalFit/mass_%0.02f_%0.02f_%0.02f_%0.02f/", sFolOpen.Data(), massBkgMin2, massBkgMax2, massBkgMin1, massBkgMax1);
    TString sFolPlot2 = Form("Plots/data/%s/FinalFit/mass_%0.02f_%0.02f_%0.02f_%0.02f/", sFolOpen.Data(), massBkgMin2, massBkgMax2, massBkgMin1, massBkgMax1);
    gSystem->Exec(Form("mkdir -p %s", sFolSave2.Data()));
    gSystem->Exec(Form("mkdir -p %s", sFolPlot2.Data()));

    TFile *f1 = new TFile(Form("%s/Totalfit_pt_%0.02f_%0.02f_%0.02f_%0.02f_%d_%d.root", sFolSave2.Data(), ptMin, ptMax, massSignalMin, massSignalMax, useRecoTemplateFitted, kExpo), "RECREATE");
    hData_InvMass->Write();
    fpsMassData->Write();
    fpsMassDataSig->Write();
    fpsMassDataBkg->Write();

    hData_Time->Write();
    fTotalFitTimeData->Write();
    fDataBkgDecayTimePart->Write();
    fNonPromptMCDecayTimePart->Write();
    fPromptMCDecayTimePart->Write();

    paramsTotalSave->Write("paramsTotal");

    chi2ndfVec_Mass->Write("chi2ndfVec_Mass");
    chi2ndfVec_Time->Write("chi2ndfVec_Time");
    fSig_fB->Write("fSig_fB");
    f1->Close();

    c4Mass5Time->SaveAs(Form("%s/2D_Mass_Time_Fit_%0.02f_%0.02f_%0.02f_%0.02f_%d_%d.pdf", sFolPlot2.Data(), ptMin, ptMax, massSignalMin, massSignalMax, useRecoTemplateFitted, kExpo));
    c1np->SaveAs(Form("%s/NPMC_Fit_%0.02f_%0.02f_%d.pdf", sFolPlot2.Data(), ptMin, ptMax, useRecoTemplateFitted));
}

Double_t CallCDFBkgDecayTimeTotal(Double_t *x, Double_t *par)
{
    double fSig = par[19];
    double ret = fSig * EvaluateCDFDecayTimeSigDistr(x[0], par) + (1. - fSig) * EvaluateCDFDecayTimeBkgDistr(x[0], par);
    return ret * par[32];
}

Double_t CallCDFInvMassTotal(Double_t *x, Double_t *par)
{
    double fSig = par[19];
    double ret = fSig * EvaluateCDFInvMassSigDistr(x[0], par) / fintmMassSig + (1. - fSig) * EvaluateCDFInvMassBkgDistr(x[0], par) / fintmMassBkg;

    return ret * par[32];
}
Double_t CallPromptMCDecayTimePart(Double_t *x, Double_t *par)
{
    double fB = par[20];
    double fSig = par[19];
    double ret = fSig * (1 - fB) * ResolutionFunction(x[0], par);
    return ret * par[32];
}
Double_t CallNonPromptMCDecayTimePart(Double_t *x, Double_t *par)
{
    double fB = par[20];
    double fSig = par[19];
    double ret = fSig * fB * ConvoluteGeneratedNPMCTime(x[0], par);
    return ret * par[32];
}
Double_t CallBkgDecayTimePart(Double_t *x, Double_t *par)
{
    double fSig = par[19];
    double ret = (1 - fSig) * EvaluateCDFDecayTimeBkgDistr(x[0], par);
    return ret * par[32];
}
Double_t CallBkgInvMassPart(Double_t *x, Double_t *par)
{
    double ret = EvaluateCDFInvMassBkgDistr(x[0], par) / fintmMassBkg;
    return ret * par[32];
}
Double_t CallSigInvMassPart(Double_t *x, Double_t *par)
{
    double ret = EvaluateCDFInvMassSigDistr(x[0], par) / fintmMassSig;
    return ret * par[32];
}

//--------------------------------------------------------------------------------------------------------
//------------------------------------ BEGINING OF MASS FUNCTION ----------------------------------------
//--------------------------------------------------------------------------------------------------------

Double_t EvaluateCDFInvMassSigDistr(Double_t m, Double_t *fPar)
{
    Double_t ret = 0;
    double nNorm = fPar[21];
    double mean = fPar[22];
    double sigma = fPar[23];
    double alpha = fPar[24];
    double n = fPar[25];

    ret = nNorm * ROOT::Math::crystalball_function(m, alpha, n, sigma, mean);
    // cout << "L475: " << m << " val = " << ret << " nNorm = " << nNorm << "  mean = " << mean << " sigma = " << sigma << " alpha = " << alpha << " n = " << n << " \n\n";

    // https://github.com/root-project/root/blob/master/math/mathcore/inc/Math/PdfFuncMathCore.h

    return ret;
}

Double_t EvaluateCDFInvMassBkgDistr(Double_t m, Double_t *fPar)
{
    Double_t ret = 0;
    double p0 = fPar[26];
    double p1 = fPar[27];
    double p2 = fPar[28];
    double p3 = fPar[29];
    double p4 = fPar[30];
    double p5 = fPar[31];
    if (kExpo)
        ret = p0 * TMath::Exp(p2 * m);

    else if (!kExpo)
        ret = p0 + p1 * m + p2 * m * m + p3 * m * m * m + p4 * m * m * m * m + p5 * m * m * m * m * m;
    return ret;
}
void ComputeMassIntegral(Double_t *fPar)
{
    Double_t npm = 20000.;
    Double_t stepm;
    Double_t mx = 0.;
    stepm = (fMassWndHigh - fMassWndLow) / npm;

    //-----------------
    Double_t iMassSig;
    Double_t intmMassSig = 0.0;
    Double_t summMassSig = 0.0;
    for (iMassSig = 1.0; iMassSig <= npm / 2.; iMassSig++)
    {
        mx = fMassWndLow + (iMassSig - .5) * stepm;
        summMassSig += EvaluateCDFInvMassSigDistr(mx, fPar);
        // cout << " L501 " << iMassSig << " mx = " << mx << "  " << summMassSig << endl;
        mx = fMassWndHigh - (iMassSig - .5) * stepm;
        summMassSig += EvaluateCDFInvMassSigDistr(mx, fPar);
        // cout << " L504 " << iMassSig << " mx = " << mx << "  " << summMassSig << endl;
    }
    intmMassSig = summMassSig * stepm;
    fintmMassSig = intmMassSig;
    //-----------------
    Double_t iMassBkg;
    Double_t intmMassBkg = 0.0;
    Double_t summMassBkg = 0.0;
    for (iMassBkg = 1.0; iMassBkg <= npm / 2.; iMassBkg++)
    {
        mx = fMassWndLow + (iMassBkg - .5) * stepm;
        summMassBkg += EvaluateCDFInvMassBkgDistr(mx, fPar);
        mx = fMassWndHigh - (iMassBkg - .5) * stepm;
        summMassBkg += EvaluateCDFInvMassBkgDistr(mx, fPar);
    }
    intmMassBkg = summMassBkg * stepm;
    if (intmMassBkg < 1.e-05)
        intmMassBkg = 1.;
    fintmMassBkg = intmMassBkg;
    cout << "Inside Compute integral: fintmMassSig = " << fintmMassSig << " fintmMassBkg " << fintmMassBkg << endl;
}

//--------------------------------------------------------------------------------------------------------
//------------------------------------ BEGINING OF TIME FUNCTION ----------------------------------------
//--------------------------------------------------------------------------------------------------------

Double_t GetGenNPMCx(Double_t x)
{
    Double_t ret = 0.;
    Double_t fShiftTemplate = 0;

    if ((hxGenNpMc->FindBin(x - fShiftTemplate) > 0) && (hxGenNpMc->FindBin(x - fShiftTemplate) < hxGenNpMc->GetNbinsX() + 1))
        ret = hxGenNpMc->Interpolate(x - fShiftTemplate);

    return ret;
}
Double_t ConvoluteGeneratedNPMCTime(Double_t x, Double_t *fPar)
{
    Double_t np = 1000.0;
    Double_t sc = 10.;
    Double_t sigma3 = 1000.;
    Double_t xprime;
    Double_t sum = 0.0;
    Double_t xlow, xupp;
    Double_t step;
    Double_t i;
    xlow = x - sc * sigma3;
    xupp = x + sc * sigma3;
    step = (xupp - xlow) / np;
    Double_t csiMCxprime = 0.;
    Double_t resolutionxdiff = 0.;
    Double_t xdiff = 0.;

    for (i = 1.0; i <= np; i++)
    {
        xprime = xlow + (i - .5) * step;
        csiMCxprime = GetGenNPMCx(xprime);
        xdiff = xprime - x;
        /*
        if (resolutionxdiff < 0.001 || resolutionxdiff > -0.001)
            resolutionxdiff = 1;
        else
            resolutionxdiff = 0;
        */
        resolutionxdiff = ResolutionFunction(xdiff, fPar);
        sum += csiMCxprime * resolutionxdiff;
    }
    double ret = (useRecoTemplateFitted) ? GetGenNPMCx(x) : (step * sum);
    return ret;
}

Double_t ConvoluteGeneratedNPMCTimeNorm(Double_t *x, Double_t *fPar)
{

    Double_t xx = x[0];
    Double_t ret = ConvoluteGeneratedNPMCTime(x[0], fPar);
    return ret * fPar[9];
}

Double_t EvaluateCDFDecayTimeSigDistr(Double_t x, Double_t *fPar)
{
    Double_t ret = 0;
    Double_t fB = fPar[20];
    Double_t funcPrompt = ResolutionFunction(x, fPar);
    Double_t funcNonPrompt = ConvoluteGeneratedNPMCTime(x, fPar); // * ResolutionFunction(x, fPar);
    ret = fB * funcNonPrompt + (1 - fB) * funcPrompt;
    return ret;
}
//--------------------------------------------------------------------------------------------------------
//------------------------------------~~~~~~~~~~~~~~~~~~~~~~~~~~~~----------------------------------------
//--------------------------------------------------------------------------------------------------------

Double_t EvaluateCDFfuncBkgPart(Double_t x, Double_t m, Double_t *fPar)
{
    Double_t ret = EvaluateCDFDecayTimeBkgDistr(x, fPar) * EvaluateCDFInvMassBkgDistr(m, fPar) / fintmMassBkg;
    return ret;
}
Double_t EvaluateCDFfuncSignalPart(Double_t x, Double_t m, Double_t *fPar)
{
    Double_t ret = EvaluateCDFDecayTimeSigDistr(x, fPar) * EvaluateCDFInvMassSigDistr(m, fPar) / fintmMassSig;
    return ret;
}

Double_t EvaluateCDFfuncNorm(Double_t x, Double_t m, Double_t *fPar)
{
    Double_t ret = 0.;
    Double_t fSig = fPar[19];
    ret = fSig * EvaluateCDFfuncSignalPart(x, m, fPar) + (1. - fSig) * EvaluateCDFfuncBkgPart(x, m, fPar);
    return ret;
}

//--------------------------------------------------------------------------------------------------------
//------------------------------------~~~~~~~~~~~~~~~~~~~~~~~~~~~~----------------------------------------
//--------------------------------------------------------------------------------------------------------

Double_t EvaluateLikelihood(Double_t *pseudoproperdecaytime, Double_t *invMass, Int_t ncand, Double_t *par)
{
    Double_t f = 0.;
    Double_t ret = 0.;

    for (Int_t i = 0; i < ncand; i++)
    {
        if (pseudoproperdecaytime[i] < -9999.)
            continue;
        f = EvaluateCDFfuncNorm(pseudoproperdecaytime[i], invMass[i], par);

        // printf("xi %f, mi %f \n",pseudoproperdecaytime[i], invMass[i]);
        if (f <= 0.)
            continue;
        ret += -2. * TMath::Log(f);
    }
    return ret;
}

void CdfFCN(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{
    TStopwatch t;
    t.Start();
    f = EvaluateLikelihood(fX, fM, nCand, par);
    TVirtualFitter::GetFitter()->GetObjectFit();
    t.Stop();

    cout << "Real time spent to calculate function == " << t.RealTime() << "  \n";
    cout << "CPU time spent to calculate function == " << t.CpuTime() << "  \n";
}

void CDFFunction(Int_t &npar, Double_t *gin, Double_t &f, Double_t *par, Int_t iflag)
{
    CdfFCN(npar, gin, f, par, iflag);
}

Int_t DoMinimization(Double_t *fPar) // performs the minimization
{

    TObject *obj = new TObject(); // Create an object (or use an existing one)
    TFitter *fitter = (TFitter *)TVirtualFitter::Fitter(obj, 32);
    fitter->SetFCN(CDFFunction);
    fitter->SetParameter(0, "resol_norm1", fPar[0], 1.e-10, 0., 1.e+06);
    fitter->SetParameter(1, "resol_mean1", fPar[1], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(2, "resol_sigma1", fPar[2], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(3, "resol_norm2", fPar[3], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(4, "resol_mean2", fPar[4], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(5, "resol_sigma2", fPar[5], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(6, "resol_alfa", fPar[6], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(7, "resol_lambd", fPar[7], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(8, "resol_norm3", fPar[8], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(9, "nTotlresol", fPar[9], 1.e-8, 0., 1.e+06);

    fitter->SetParameter(10, "f_plus", fPar[10], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(11, "f_minus", fPar[11], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(12, "f_Sym", fPar[12], 1.e-08, 0., 1.e+06);
    fitter->SetParameter(13, "f_Sym1", fPar[13], 1.e-08, 0., 1.e+06);

    fitter->SetParameter(14, "lambda_plus", fPar[14], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(15, "lambda_minus", fPar[15], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(16, "lambda_Sym", fPar[16], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(17, "lambda_Sym1", fPar[17], 1.e-8, 5.e-04, 5.e+03);

    fitter->SetParameter(18, "norm", fPar[18], 1.e-8, 5.e-04, 5.e+03);

    fitter->SetParameter(19, "f_Sig", fPar[19], 1.e-8, 0.23, 0.96);
    fitter->SetParameter(20, "f_B", fPar[20], 1.e-8, 0.000001, 0.99999);

    // ---- INV MASS PARAMTERS ------
    fitter->SetParameter(21, "CB_Normalisation", fPar[21], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(22, "CB_mean", fPar[22], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(23, "CB_sig", fPar[23], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(24, "CB_alpha", fPar[24], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(25, "CB_n", fPar[25], 1.e-8, 5.e-04, 5.e+03);

    fitter->SetParameter(26, "exp_p0_gausNorm", fPar[26], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(27, "exp_p1_gausMean", fPar[27], 1.e-8, 5.e-04, 5.e+03);
    fitter->SetParameter(28, "exp_p2_gausSig", fPar[28], 1.e-8, -5.e-04, 5.e+03);

    fitter->SetParameter(29, "poly_p3_x3", fPar[29], 1.e-8, -5.e-04, 5.e+03);
    fitter->SetParameter(30, "poly_p4_x4", fPar[30], 1.e-8, -5.e-04, 5.e+03);
    fitter->SetParameter(31, "poly_p5_x5", fPar[31], 1.e-8, -5.e-04, 5.e+03);

    //
    fitter->GetMinuit()->SetErrorDef(0.5);

    // ---- FIXING BKG TIME PARAMTERS ------
    fitter->FixParameter(0);
    fitter->FixParameter(1);
    fitter->FixParameter(2);
    fitter->FixParameter(3);
    fitter->FixParameter(4);
    fitter->FixParameter(5);
    fitter->FixParameter(6);
    fitter->FixParameter(7);
    fitter->FixParameter(8);
    fitter->FixParameter(9);  // nTotlresol
    fitter->FixParameter(10); // f_plus
    fitter->FixParameter(11); // f_neg
    fitter->FixParameter(12); // f_Sym
    fitter->FixParameter(13); // f_Sym1
    fitter->FixParameter(14); // lambda
    fitter->FixParameter(15); // lambda
    fitter->FixParameter(16); // lambda
    fitter->FixParameter(17); // lambda_Sym1
    fitter->ReleaseParameter((Int_t)18);
    fitter->FixParameter((Int_t)19);
    // fitter->ReleaseParameter((Int_t)19);
    // fitter->FixParameter((Int_t)20);
    fitter->ReleaseParameter((Int_t)20);
    fitter->FixParameter(21); // CB_Norm
    fitter->FixParameter(22); // CB_mean
    fitter->FixParameter(23); // CB_sig
    fitter->FixParameter(24); // CB_alpha
    fitter->FixParameter(25); // CB_n
    fitter->FixParameter(26); // exp p0
    fitter->FixParameter(27); // exp p1
    fitter->FixParameter(28); // gaus param
    fitter->FixParameter(29); // poly
    fitter->FixParameter(30); // poly
    fitter->FixParameter(31); // poly

    cout << " L630 " << endl;
    Double_t arglist[2] = {10000, 0.1};
    Int_t iret = 0;

    iret = fitter->ExecuteCommand("MIGRAD", arglist, 2);

    fitter->PrintResults(4, 0);

    cout << "Minimization procedure finished\n";
    for (Int_t i = 0; i < 32; i++)
    {
        Double_t paramValue = fitter->GetParameter(i);
        Double_t paramError = fitter->GetParError(i);
        cout << "Parameter " << i << ": Value = " << paramValue << ", Error = " << paramError << endl;
        fValPar[i] = paramValue;
        fValParErr[i] = paramError;
    }
    return iret;
}

Double_t RecoNonPromptJpsiTemplate(Double_t *x, Double_t *par)
{

    Double_t norm1 = par[0];
    Double_t mean1 = par[1];
    Double_t sigma1 = par[2];

    Double_t norm2 = par[3];
    Double_t slope = par[4];
    Double_t xx = x[0];
    double G1 = norm1 * TMath::Gaus(xx, mean1, sigma1, kTRUE);
    double ExpVal = xx > 0. ? norm2 * slope * TMath::Exp(-1 * xx * slope) : 0.;
    return par[5] * (G1 + ExpVal) / (norm1 + norm2);
}

void ReadCandidates_old(TNtuple *tree, Double_t *&pseudoproper, Double_t *&invmass, Double_t *&pt, Int_t &ncand)
{

    // ncand = 0;
    TString arrType[] = {"SS", "FS", "FF"};

    if (!tree)
        return; // Skip if the tree doesn't exist

    Float_t mJPSI = 0;
    Float_t x = 0;
    Float_t type = 0;
    Float_t transvMom = 0.;
    Int_t nentries = 0;
    // tree->Print();
    tree->SetBranchAddress("Xdecaytime", &x);
    tree->SetBranchAddress("Mass", &mJPSI);
    tree->SetBranchAddress("Pt", &transvMom);

    nentries = (Int_t)tree->GetEntries();

    pseudoproper = new Double_t[nentries];
    invmass = new Double_t[nentries];
    pt = new Double_t[nentries];

    for (Int_t i = 0; i < nentries; i++)
    {
        tree->GetEntry(i);
        pseudoproper[ncand] = (Double_t)x * 10000.;
        invmass[ncand] = (Double_t)mJPSI;
        pt[ncand] = (Double_t)transvMom;
        ncand++;
    }
    return;
}
